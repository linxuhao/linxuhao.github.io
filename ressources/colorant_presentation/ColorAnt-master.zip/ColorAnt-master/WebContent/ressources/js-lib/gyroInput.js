// constant to convert degrees to radians
var angleConversion = 0.01745329252;

// to compute the sliding median of angles
var medianSize = 7;
var alphaMedianTable = [];
var betaMedianTable = [];
var alphaMedian = 0;
var betaMedian = 0; 

// to compute the sliding average of angles
var averageSize = 7;
var alphaAverageTable = [];
var betaAverageTable = [];
var alphaAverage = 0;
var betaAverage = 0;

// initialization boolean and initial values
var isInitialized = false;
var initAlpha;
var initBeta;

// distance to screen (use this to change sensitivity : the closer to 0, the slower)
var dist;
var maxAngle = 60;

// original angles ranges (might depend on the browser !)
// Todo : si c'est nécessaire, tester le browser utilisé lors de l'initialisation et changer ces valeurs
var minAlpha = 0;
var maxAlpha = 360;
var minBeta = -180;
var maxBeta = 180;

var oldPositionX = 0;
var oldPositionY = 0;

var currentRatio = 0.6;

function initAngles(){
	initAlpha = mathMapValue(event.alpha,minAlpha,maxAlpha,0,360);
	initBeta = mathMapValue(event.beta,minBeta,maxBeta,0,360);
}

function deviceOrientation(event) {
	// set init angles
	// this supposes that the initial position corresponds to the center of the main screen
	if(!isInitialized)
	{
		initAngles();
		isInitialized = true;
	}
	
	var alphaMedian = mathCenterMod(event.alpha,180);
	var betaMedian = event.beta; 
	
	// manage sliding median on angles
	if (alphaMedianTable.length >= medianSize)
	{
		// exclude the older values from the tables
		alphaMedianTable.shift();
		betaMedianTable.shift();
		
		// enter the new values 
		alphaMedianTable.push(alphaMedian);
		betaMedianTable.push(betaMedian);
		
		var alphaTableTemp = alphaMedianTable.slice();
		var betaTableTemp = betaMedianTable.slice();
		alphaTableTemp.sort(function(a, b){return a - b}); 
		betaTableTemp.sort(function(a, b){return a - b}); 
		
		if (alphaTableTemp.length % 2 == 0){
			alphaMedian = (alphaTableTemp[alphaTableTemp.length/2] + 
							alphaTableTemp[alphaTableTemp.length/2 - 1])/2;
			betaMedian = (betaTableTemp[betaTableTemp.length/2] + 
							betaTableTemp[betaTableTemp.length/2 - 1])/2;
		}    
		else{
			alphaMedian = alphaTableTemp[Math.round(alphaTableTemp.length/2)];
			betaMedian = betaTableTemp[Math.round(betaTableTemp.length/2)];
		}
	}
	else
	{
		alphaMedianTable.push(alphaMedian);
		betaMedianTable.push(betaMedian);
	}
	
	
	// manage sliding average on angle
	if (alphaAverageTable.length >= averageSize)
	{
		// exclude the older values from the tables
		alphaAverageTable.shift();
		betaAverageTable.shift();
		
		// enter the new values 
		alphaAverageTable.push(alphaMedian);
		betaAverageTable.push(betaMedian);
		
		// average of position in x and y
		alphaAverage = 0;
		betaAverage = 0;
		
		for(i = 0; i < averageSize; i++){
			alphaAverage += alphaAverageTable[i];
			betaAverage += betaAverageTable[i];
		}
		
		alphaAverage /= averageSize;
		betaAverage /= averageSize;
	}
	else
	{
		// enter the new values 
		alphaAverageTable.push(alphaMedian);
		betaAverageTable.push(betaMedian);
		alphaAverage = alphaMedian;
		betaAverage = betaMedian;
	}  
	
	var curAlpha = mathMapValue(alphaAverage,minAlpha,maxAlpha,0,360);
	var curBeta = mathMapValue(betaAverage,minBeta,maxBeta,0,360);
    	

	// we bound the angle to avoid infinite tangent result
	var angleAlpha = mathCenterMod(initAlpha - curAlpha, 180);
	angleAlpha = mathBound(angleAlpha, -maxAngle, maxAngle);
	var angleBeta = mathCenterMod(initBeta - curBeta, 180);
	angleBeta = mathBound(angleBeta, -maxAngle, maxAngle);
	
	// deduce position according to angle
	var positionX = Math.tan(angleAlpha*angleConversion) * dist; // conversion to radians
	var positionY = Math.tan(angleBeta*angleConversion) * dist;
	
	// map to the screen dimensions
	positionX += width / 2;
	positionY += height / 2;
	
	// secure data with a bound
	positionX = mathBound(positionX, 0, width);
	positionY = mathBound(positionY, 0, height);
    //round before check and send
	positionX = Math.round(positionX);
	positionY = Math.round(positionY);
	// send new position if position changed
	if(positionX != oldPositionX || positionY != oldPositionY){
   		//console.log("sending position : old (" + oldPositionX + ", " + oldPositionY + "), new (" + xMove + ", " + yMove + ")");

   		var currentPositionX = currentRatio * positionX + (1 - currentRatio) * oldPositionX;
   		var currentPositionY = currentRatio * positionY + (1 - currentRatio) * oldPositionY;
   		
   		oldPositionX = positionX;
   		oldPositionY = positionY;
   		
		sendToServer(currentPositionX, currentPositionY);
	}
    	
	// debug logs
	document.getElementById("beta").innerHTML=Math.round(event.beta) + " " + betaMedian;
	document.getElementById("gamma").innerHTML=Math.round(event.gamma) + " " + alphaMedian;
	document.getElementById("xPos").innerHTML=positionX;
	document.getElementById("yPos").innerHTML=positionY;
}

function endDeviceOrientationListenning(){
	window.removeEventListener('deviceorientation', deviceOrientation);
}
function beginDeviceOrientationListenning(){
	// move listener
	window.addEventListener('deviceorientation', deviceOrientation);
}

// Todo: déplacer ces 2 méthodes vers une classe "utils" ? :

// Maps the value in_value, which is between in_min and in_max, to the corresponding value between out_min and out_max
function mathMapValue (in_value, in_min, in_max, out_min, out_max) 
{
	  return out_min + ((in_value-in_min) / (in_max - in_min) * (out_max - out_min));
}

// Returns value bounded between min and max (included)
function mathBound (value, min, max) 
{
	  if (value > max)
		  return max;
	  if (value < min)
		  return min;
	  return value;
}

//Returns the centered modulo n of p (the returned value is between -n and n)
function mathCenterMod(p,n){
	var temp = (p+2*n)%(2*n);
	
	if(temp>n)
		temp -= (2*n);
	
	return temp;
}
