package mason.gui;

import java.awt.Graphics2D;

import mason.model.Ink;
import sim.portrayal.DrawInfo2D;
import sim.portrayal.simple.RectanglePortrayal2D;

public class InkPortrayal2D extends RectanglePortrayal2D {
	private static final long serialVersionUID = 1L;

	public void draw(Object object, Graphics2D graphics, DrawInfo2D info)
	{
		Ink obj = (Ink) object; 
		paint = obj.getColor();
		super.draw(object, graphics, info);
	}

}
