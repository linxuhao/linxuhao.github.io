package mason.model;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentSkipListSet;

public class Observer {
	
	// liste de notifications
	private ConcurrentHashMap<Long, DisplayableAgent> player;
	private ConcurrentHashMap<Long, DisplayableAgent> insect;
	private ConcurrentHashMap<Long, DisplayableAgent> monster;
	private ConcurrentHashMap<Long, DisplayableAgent> collectable;
	private ConcurrentSkipListSet<Long> deadInsects;
	private ConcurrentSkipListSet<Long> explosions;
	private boolean scoreChanged;
	

	public Observer(){
		player = new ConcurrentHashMap<Long, DisplayableAgent>();
		insect = new ConcurrentHashMap<Long, DisplayableAgent>();
		monster = new ConcurrentHashMap<Long, DisplayableAgent>();
		collectable = new ConcurrentHashMap<Long, DisplayableAgent>();
		deadInsects = new ConcurrentSkipListSet<Long>();
		explosions = new ConcurrentSkipListSet<Long>();
		setScoreChanged(false);
	}
	
	public void clear()
	{
		player.clear();
		insect.clear();
		collectable.clear();
		monster.clear();
		deadInsects.clear();
		explosions.clear();
		setScoreChanged(false);
	}
	
	public void addNotification(DisplayableAgent obj){
		if(obj instanceof PlayerPointer){
			player.put(obj.getDisplayId(), obj); 
		}
		
		if(obj instanceof Insect){
			if(((Insect)obj).isDead()) {
				deadInsects.add(obj.getDisplayId());
				if(((Insect)obj).isExplosed())
					explosions.add(((Insect)obj).getDisplayId());
			}
			else
				insect.put(obj.getDisplayId(), obj); 
		}
		if(obj instanceof Collectable){
			collectable.put(obj.getDisplayId(), obj); 
		}
		if(obj instanceof Monster){
			monster.put(obj.getDisplayId(), obj); 
		}
	}

	public boolean haveNotification(){
		return !player.isEmpty() || !insect.isEmpty() || !monster.isEmpty() || !collectable.isEmpty() || !deadInsects.isEmpty();
	}

	public Map<Long, DisplayableAgent> getPlayer() {
		return player;
	}

	public void setPlayer(ConcurrentHashMap<Long, DisplayableAgent> player) {
		this.player = player;
	}

	public Map<Long, DisplayableAgent> getInsect() {
		return insect;
	}

	public void setInsect(ConcurrentHashMap<Long, DisplayableAgent> insect) {
		this.insect = insect;
	}

	public Map<Long, DisplayableAgent> getMonster() {
		return monster;
	}

	public void setMonster(ConcurrentHashMap<Long, DisplayableAgent> monster) {
		this.monster = monster;
	}

	public Map<Long, DisplayableAgent> getCollectable() {
		return collectable;
	}

	public void setCollectable(ConcurrentHashMap<Long, DisplayableAgent> collectable) {
		this.collectable = collectable;
	}

	public Set<Long> getDeadInsects() {
		return deadInsects;
	}

	public void setDeadInsects(ConcurrentSkipListSet<Long> deadInsects) {
		this.deadInsects = deadInsects;
	}

	public Set<Long> getExplosions() {
		return explosions;
	}

	public void setExplosions(ConcurrentSkipListSet<Long> explosions) {
		this.explosions = explosions;
	}

	public boolean isScoreChanged() {
		return scoreChanged;
	}

	public void setScoreChanged(boolean scoreChanged) {
		this.scoreChanged = scoreChanged;
	}

}
