package mason.model;

/**
 * now work as a field in existing class
 * 
 *
 */
public abstract class Notificator extends ComplexDisplayableAgent{

	public boolean changed = false;
	
	public boolean isChanged() {
		return changed;
	}

	public void setChanged(boolean changed) {
		this.changed = changed;
	}

	public void notifyObserver(World beings, DisplayableAgent obj)
	{
		// notifies only if there was a change
		if (changed){
			beings.observer.addNotification(obj);
			changed = false;
		}	
	}
}
