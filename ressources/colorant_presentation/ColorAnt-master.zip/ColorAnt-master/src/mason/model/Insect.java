package mason.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.fasterxml.jackson.annotation.JsonIgnore;

import game.constants.InkType;
import sim.engine.SimState;
import sim.field.grid.SparseGrid2D;
import sim.util.Bag;
import sim.util.Int2D;

public class Insect extends Existing {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * the insect can perceive every thing under PERCEPTION distance (in cases)
	 */
	public static final int PERCEPTION_COLLECTABLE = 60;
	
	public static final int PERCEPTION_DIRECTION = 20;
	
	/**
	 * speed (cases per frame) when the insect is propulsed 
	 */
	public static final int PROPULSED_SPEED = 50;
	
	/**
	 * speed (cases per frame) when the insect is walking
	 */
	public static final int NORMAL_SPEED = 9;
	
	/**
	 * counter for explosing time
	 */
	int explosingIn = EXPLOSING_TIME;
	
	
	protected boolean isDead = false;
	
	/**
	 * Every object perceived by the insect (insects excluded)
	 */
	
	List<Collectable> collectableList = new ArrayList<Collectable>();
	
	List<Ink> directionInkList = new ArrayList<Ink>();
	
	/**
	 * how many steps to wait when stucked
	 */
	public static final int STUCKED_TIME= 18;
	
	/**
	 * counter to count stucked time
	 */
	int waiting = STUCKED_TIME;
	
	/**
	 * the objectives of the insect can be either looking for direction ink or for collectable 
	 */
	private enum Objective {
		Pheromone,
		Collectable;
	}
	
	/**
	 * the current objective of the insect, by default it's Pheromone
	 */
	//Objective objective = Objective.Collectable;
	Objective objective = Objective.Pheromone;
	
	
	/**
	 * is the insect carrying a collectable?
	 */
	Collectable collectable = null;
	
	
	/**
	 * the width of the Insect
	 */
	int insectWidth = 6;
	
	/**
	 * the height of the Insect
	 */
	int insectHeight = 6;
	
	/**
	 * dead by explosion ?
	 */
	boolean explosed = false;
	

	/**
	 * generate a new insect at coord with given id
	 */
	public Insect(World beings, Int2D coord, long id)
	{
		super(beings);
		perceive(beings);
		setState(State.Normal);
		speed = NORMAL_SPEED;
		x = coord.x;
		y = coord.y;
		goalX = coord.x;
		goalY = coord.y;
		realPositionX = (float)x;
		realPositionY = (float)y;
		displayId = id;
		
		changed = true;
		notifyObserver(beings, this);
	}

	/**
	 * override setState to modify speed and drop collectable according to given state
	 */
	@Override
	public void setState(State state)
	{
		if(this.state != state)
		{
			switch(state)
			{
				case Stuck : changeSpeed(0); break;
				case Normal : changeSpeed(NORMAL_SPEED); break;
				case Propulsed : changeSpeed(PROPULSED_SPEED); break; 
			}
			
			super.setState(state);
		}
	}
	
	private void dropCollectable(World beings)
	{
		if (collectable != null)
		{
			collectable.drop(beings);
			collectable = null;
		}
		
		objective=Objective.Pheromone;
	}
	
	/**
	 * fill the list of perceived inks and collectables
	 */
	private void perceive(World beings) 
	{
		collectableList.clear();
		directionInkList.clear();
		
		SparseGrid2D grid = beings.getYard();
		
		for(int i = -PERCEPTION_COLLECTABLE; i <= PERCEPTION_COLLECTABLE; i++)
			for(int j = -PERCEPTION_COLLECTABLE; j <= PERCEPTION_COLLECTABLE; j++)
			{
				Bag objects = grid.getObjectsAtLocation(clamp(x + i, 0, beings.getWidth()), clamp(y + j, 0, beings.getHeight()));
				
				if(objects != null)
					for(Object o : objects) 
						if(o != null && o instanceof Collectable)
							collectableList.add((Collectable)o);
			}
		
		for(int i = -PERCEPTION_DIRECTION; i <= PERCEPTION_DIRECTION; i++)
			for(int j = -PERCEPTION_DIRECTION; j <= PERCEPTION_DIRECTION; j++)
			{
				Bag objects = grid.getObjectsAtLocation(clamp(x + i, 0, beings.getWidth()), clamp(y + j, 0, beings.getHeight()));
				
				if(objects != null)

					for(Object o : objects) 
						if(o != null && o instanceof Ink && ((Ink)o).getType() == InkType.Diriger)
							directionInkList.add((Ink)o);
			}
		
		
		if(isDebuging())
			if(this.displayId == 2)
					System.out.println("perceived ink : " + directionInkList + " collectableList : " + collectableList);
	}
	
	
	
	
	/**
	 * choose the place to reach
	 */
	private Int2D nextGoal(World beings)
	{
		Int2D goal = null;
		
		switch (objective)
		{
			case Pheromone : goal = findBestPheromone(); break;
			case Collectable : goal = findClosestCollectable(); break;
		}
		
		// random move
		if (goal == null)
		{
			Random rand = new Random();

			int gX = clamp(x + rand.nextInt(2*PERCEPTION_DIRECTION) - PERCEPTION_DIRECTION, 0, beings.getWidth());
			int gY = clamp(y + rand.nextInt(2*PERCEPTION_DIRECTION) - PERCEPTION_DIRECTION, 0, beings.getHeight());
			
			goal = new Int2D (gX,gY);
		}
		
		// TODO : remove this (just for debug test)
		//goal = new Int2D(50,110);
		
		if(isDebuging())
			if(this.displayId == 2)
				System.out.println("goal :" + goalX + " " + goalY);
		
		return goal;
	}
	

	/**
	 * choose the strongest direction pheromone (according to its id instead of level now, because since we can draw multiple inks in same frame, they have same level)
	 */
	private Int2D findBestPheromone() 
	{
		Int2D location = null;
		
		if(!directionInkList.isEmpty())
		{
			long max = directionInkList.get(0).getDisplayId();
			location = new Int2D(directionInkList.get(0).getX(),directionInkList.get(0).getY());
			
			for(Ink i : directionInkList)
				if (i.getDisplayId() > max)
				{
					max = i.getDisplayId();
					location = new Int2D(i.getX(), i.getY());
				}
		}
		
		if(isDebuging())
			if(this.displayId == 2)
				if(location != null)
					System.out.println("best pheromone, x :" + location.x + " y : " + location.y);
		
		return location;
	}
	
	
	/**
	 * find the closest collectable
	 */
	private Int2D findClosestCollectable() 
	{
		Int2D location = null;
		
		if(!collectableList.isEmpty())
		{
			location = new Int2D(collectableList.get(0).getX(), collectableList.get(0).getY());
			int minDistance = distanceToLocation(location.x, location.y);
			
			for(Collectable c : collectableList)
			{
				int distance = distanceToLocation(c.getX(), c.getY());
				if( distance < minDistance)
				{
					location = new Int2D(c.getX(), c.getY());
					minDistance = distance;
				}
			}
		}
		
		if(isDebuging())
			if(this.displayId == 2)
				if(location != null)
					System.out.println("best collectable, x :" + location.x + " y : " + location.y);
		
		return location;
	}
	
	
	/**
	 * is the insect on an ink of the specified type?
	 */
	/*private boolean onInk(World beings, InkType type)
	{*/
		/*SparseGrid2D grid = beings.getYard();
		
		for(int i = -insectWidth; i <= insectWidth; i++)
			for(int j = -insectHeight; j <= insectHeight; j++)
			{
				Bag objects = grid.getObjectsAtLocation(setWithinARange(x + i, 0, beings.getWidth(), 0, beings.getWidth()), setWithinARange(y + j, 0, beings.getHeight(),0, beings.getHeight())); 
				if(objects != null)
					for(Object o : objects) 
						if (o instanceof Ink && ((Ink)o).getType() == type)
							return true;
			}
		*/
		/*InkType bestType = bestInk(beings);
		return bestType == type;
	}*/
	
	/**
	 * what is the most recent ink beside the insect?
	 */
	private InkType bestInk(World beings)
	{
		SparseGrid2D grid = beings.getYard();
		long bestId = 0;
		InkType bestType = InkType.None;
		
		for(int i = -insectWidth; i <= insectWidth; i++)
			for(int j = -insectHeight; j <= insectHeight; j++)
			{
				Bag objects = grid.getObjectsAtLocation(clamp(x + i, 0, beings.getWidth()), clamp(y + j, 0, beings.getHeight())); 
				if(objects != null)
					for(Object o : objects) 
						if (o instanceof Ink && ((Ink)o).getDisplayId()>bestId)
						{
							bestId = ((Ink)o).getDisplayId();
							bestType = ((Ink)o).getType();
						}
			}
		return bestType;
	}
	
	
	
	/**
	 * behaviour of the insect
	 */
	@Override
	public void step(SimState beings) {
		
		if(!isDead()){
			//for debug (TODO : remove this)
			if(isDebuging())
				if(this.displayId == 2)
					System.out.println("step: state = " + state + "   objective : "+ objective);
			
			InkType bestInk = bestInk((World)beings);
			
			// react according to position and state
			switch(state)
			{
				case Stuck : 
					// is it still on stucking ink ?
					if(bestInk != InkType.Immobiliser)
					{
						// if no, go back to normal state
						setState(State.Normal);
						waiting = STUCKED_TIME;
					}
					// if yes stay stuck
					break;
				
				case Normal : 
					// move
					for(int i =0; i < speed && !onGoal() && state!=State.Stuck && !isDead; i++)
					{
						oneMoveTo(new Int2D(goalX, goalY), (World)beings);
						
						bestInk = bestInk((World)beings);

						// make the collectable carried follow it
						if (isLoaded())
							collectable.follow(this, (World)beings);
						
						// count successive explosive inks
						if(bestInk == InkType.Exploser)
						{
							explosingIn--;
							if(explosingIn == 0)
								explose((World)beings);
						}
						else{
							explosingIn = EXPLOSING_TIME;
						}
							
						
						switch(bestInk) 
						{
							case Diriger :
								objective=Objective.Pheromone; break;
							case Immobiliser :
								setState(State.Stuck); break;
							case Lacher :
								dropCollectable((World)beings); break;
							case Collecter :
								objective=Objective.Collectable; break;
							default : break;
						}
						
						
						
						// if collectable TODO : il ne faut pas qu'elle ait déjà un collectable
						if(objective==Objective.Collectable)
							tryToCollect((World)beings);
						
					}
					break;
					
				case Propulsed : 
					
					dropCollectable((World)beings);
					
					// move
					for(int i =0; i < speed && !onGoal() && state!=State.Stuck; i++)
					{
						oneMoveTo(new Int2D(goalX, goalY), (World)beings);
						
						bestInk = bestInk((World)beings);
						
						// count successive explosive inks
						if(bestInk == InkType.Exploser)
						{
							explosingIn--;
							if(explosingIn == 0)
								explose((World)beings);
						}
						else
							explosingIn = EXPLOSING_TIME;
						
					
						switch(bestInk) 
						{
							case Diriger :
								objective=Objective.Pheromone; break;
							case Immobiliser :
								setState(State.Stuck); break;
							case Lacher :
								dropCollectable((World)beings); break;
							case Collecter :
								objective=Objective.Collectable; break;
							default : break;
						}
						
						
					}
					//if the goal is reached, the state goes back to normal
					if(onGoal())
						setState(State.Normal);
					break;
			}
			
			// perceive
			perceive((World)beings);
			
			// choose new goal
			if (state == State.Normal)
				changeGoal(nextGoal((World)beings));
			
			// notifications
			super.step(beings);
		}	
	}

	private void tryToCollect(World beings)
	{
		Bag objects = beings.getYard().getObjectsAtLocation(this.x, this.y);
			
		if(objects != null)
			for(Object o : objects)
				if (o instanceof Collectable && ((Collectable)o).collect(beings, this))
				{
					collectable = (Collectable)o;
					objective=Objective.Pheromone;
					if(isDebuging())
						if(this.displayId == 2)
								System.out.println("collecté!");
				}
			
	}
	
	
	/**
	 * returns distance between this insect and the specified location
	 */
	private int distanceToLocation(int x, int y){
		int xDistance = Math.abs(x - this.x);
		int yDistance =  Math.abs(y - this.y);
		return Math.max(xDistance, yDistance);
	}
	
	/**
	 * explose and propulse agents around it
	 */
	public void explose(World beings)
	{
		if(isDebuging())
		{
			System.out.println("Explosing");
		}
		
		//propulse agents around him
		SparseGrid2D grid = beings.getYard();
		
		for(int i = -PROPULSING_AREA; i <= PROPULSING_AREA; i++)
			for(int j = -PROPULSING_AREA; j <= PROPULSING_AREA; j++)
			{
				Bag objects = grid.getObjectsAtLocation(clamp(x + i, 0, beings.getWidth()), clamp(y + j, 0, beings.getHeight())); 
				if(objects != null)
					for(Object o : objects) 
						if(o instanceof Existing)
							((Existing) o).propulsed(beings, new Int2D(this.x, this.y));
			}  
        
		explosed = true;
		die(beings);
	}
	
	/**
	 * remove insect from the yard and stop it
	 */
	public void die(World beings)
	{
		if(collectable != null) {
			collectable.drop(beings);
			collectable = null;
		}
		
		if(isDebuging())
		{
			System.out.println("Dying");
		}
		beings.getYard().remove(this);
		stoppable.stop();
		isDead = true;
		changed = true;
		beings.getInsectGenerator().currentInsectNumber--;
		//System.out.println("Insect -> Insect died : " + getDisplayId());
		this.notifyObserver(beings,this);
	}
	
	@Override
	public void propulsed(World beings, Int2D explosionCoord)
	{
		if(collectable != null) {
			collectable.drop(beings);
			collectable = null;
		}
			
		super.propulsed(beings, explosionCoord);
	}
	
	@JsonIgnore
	public boolean isDead() {
		return isDead;
	}
	
	public Objective getObjective()
	{
		return objective;
	}
	
	public boolean  isLoaded()
	{
		return (collectable!=null);
	}

	public boolean isExplosed() {
		return explosed;
	}
}
