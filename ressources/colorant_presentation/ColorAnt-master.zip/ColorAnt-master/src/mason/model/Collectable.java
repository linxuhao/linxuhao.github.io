package mason.model;

import sim.engine.SimState;
import sim.util.Int2D;

public class Collectable extends Existing {

	private boolean carried;
	public boolean isCarried() {
		return carried;
	}

	private Insect ant;
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	public static final int NORMAL_SPEED = Insect.NORMAL_SPEED;
	
	/**
	 * speed (cases per frame) when the collectable is propulsed 
	 */
	public static final int PROPULSED_SPEED = 60;

	public Collectable(World world, Int2D location) {
		super(world);
		this.setDisplayId(world.generateDisplayId());
		state = State.Normal;
		speed = NORMAL_SPEED;
		x = location.x;
		y = location.y;
		realPositionX = (float)x;
		realPositionY = (float)y;
		goalX = location.x;
		goalY = location.y;
		changed = true;
	}
	
	public boolean collect(World beings, Insect ant)
	{
		if (ant == null)
			return false;
		
		if(!carried)
		{
			carried = true;
			changed = true;
			notifyObserver(beings, this);
			this.ant = ant;
			return true;
		}
		
		return false;
	}
	
	public void drop(World beings)
	{
		if(state==State.Normal)
		{
			carried = false;
			changed = true;
			ant.collectable = null;
			ant = null;
			goalX = x;
			goalY = y;
			
			notifyObserver(beings, this);
		}
	}
	
	public void follow(Insect master, World beings)
	{
		if (master == this.ant && carried)
		{
			changeGoal(new Int2D(ant.getGoalX(), ant.getGoalY()));	
			
			this.x = ant.x+5; // TODO : change offset of collectable relatively to ant
			this.y = ant.y;
			beings.getYard().setObjectLocation(this, this.x, this.y);
			
			notifyObserver(beings, this);
		}
	}
	
	@Override
	public void step(SimState beings) 
	{
		// todo: notify to change score based on position changes (area changes)
		
		if(state==State.Propulsed) 
		{
			// move
			for(int i =0; i < speed && !onGoal(); i++)
				oneMoveTo(new Int2D(goalX, goalY), (World)beings);
			
			//if the goal is reached, the state goes back to normal
			if(onGoal())
				setState(State.Normal);
		}
		
		// notifications
		super.step(beings);
	}

	
	/**
	 * override setState to modify speed according to given state
	 */
	@Override
	public void setState(State state)
	{
		if(this.state != state)
		{
			//changed = true; //TODO : decomment if you want notification when state changes (for animations)
			
			switch(state)
			{
				case Normal : changeSpeed(NORMAL_SPEED); break;
				case Propulsed : changeSpeed(PROPULSED_SPEED); break; 
				default : break;
			}
			
			super.setState(state);
		}
	}
	
}
