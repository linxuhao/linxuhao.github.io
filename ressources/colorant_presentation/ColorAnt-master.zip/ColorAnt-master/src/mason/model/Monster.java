package mason.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

import sim.engine.SimState;
import sim.field.grid.SparseGrid2D;
import sim.util.Bag;
import sim.util.Int2D;

public class Monster extends Existing {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * the insect can perceive every thing under PERCEPTION distance (in cases)
	 */
	public static final int PERCEPTION = 150;
	
	/**
	 * speed (cases per frame) when the monster is propulsed
	 */
	public static final int PROPULSED_SPEED = 60;
	
	/**
	 * speed (cases per frame) when the monster is walking
	 */
	public static final int NORMAL_SPEED = 15;
	
	/**
	 * monsters can't approach the ant's hole closer than this distance
	 */
	int MIN_DIST = 50;
	
	/**
	 * Insects targeted by the monster 
	 */
	Insect target_insect = null;
	
	/**
	 * the width of the Monster
	 */
	int monsterWidth = 3;
	
	/**
	 * the height of the Monster
	 */
	int monsterHeight = 3;
	
	
	Random rand;
	
	/**
	 * probability to look for another target when tracking one
	 */
	float probability = 0.3f;
	
	public Monster(World beings, Int2D coord, long id)
	{
		super(beings);
		rand = new Random();
		setState(State.Normal);
		speed = NORMAL_SPEED;
		x = coord.x;
		y = coord.y;
		realPositionX = (float)x;
		realPositionY = (float)y;
		displayId = id;
		target_insect = null;
		goalX = x;
		goalY = y;
		changed = true;	
	}
	
	
	/**
	 * get the list of perceived insects
	 */
	private List<Insect> perceive(World beings) 
	{
		List<Insect> perceivedList = new ArrayList<Insect>();
		SparseGrid2D grid = beings.getYard();
		
		for(int i = -PERCEPTION; i <= PERCEPTION; i++)
			for(int j = -PERCEPTION; j <= PERCEPTION; j++)
			{
				Bag objects = grid.getObjectsAtLocation(clamp(x + i, 0, beings.getWidth()), clamp(y + j, 0, beings.getHeight())); 
				if(objects != null)
					for(Object o : objects) 
						if(o instanceof Insect)
							perceivedList.add((Insect)o);
			}
		
		return perceivedList;	
	}
	
	
	/**
	 * override setState to modify speed and drop collectable according to given state
	 */
	@Override
	public void setState(State state)
	{
		if(this.state != state)
		{
			switch(state)
			{
				case Normal : changeSpeed(NORMAL_SPEED); break;
				case Propulsed : changeSpeed(PROPULSED_SPEED); break; 
				default : break;
			}
			
			super.setState(state);
		}
	}
	
	
	/**
	 * Look for insects, considering those heading, then chose the "closest" as the victim
	 */
	private void lookForTarget(World beings) {
		List<Insect> insectInSight = this.perceive(beings);
		if (insectInSight.size() == 0) return;

		//TODO: Take heading into account
		List<Insect> targets = insectInSight.stream()
		.filter(p -> isReachable(beings, p.x, p.y)) // avoinding ant's hole
		.collect(Collectors.toList());
		if (targets.size() == 0) return;
		
		Collections.sort(targets,new SortByDistance());
		target_insect = (Insect)targets.get(0);
	}
	
	private boolean isReachable(World beings, int a, int b)
	{
		Int2D center = new Int2D(beings.getWidth()/2, beings.getHeight()/2);
		
		boolean isReachable = true;
		
		if(x <= center.x)
		{
			if(y <= center.y)
			{
				if(a >= center.x - MIN_DIST && b >= center.y - MIN_DIST)
					isReachable = false;
			}
			else
				if(a >= center.x - MIN_DIST && b <= center.y + MIN_DIST)
					isReachable = false;
		}
		
		else
		{
			if(y <= center.y)
			{
				if(a <= center.x + MIN_DIST && b >= center.y - MIN_DIST)
					isReachable = false;
			}
			else
				if(a <= center.x + MIN_DIST && b <= center.y + MIN_DIST)
					isReachable = false;
		}
		
		return isReachable;
	}
	
	
	@Override
	public void step(SimState beings) 
	{
		switch(state)
		{
			case Normal : 
				
				// move to target
				for(int i =0; i < speed && !onGoal(); i++) {
					oneMoveTo(new Int2D(goalX, goalY), (World)beings);
				}
				// if it reaches the insect
				if (target_insect!=null && !target_insect.isDead && this.onTarget(target_insect.x, target_insect.y)) 
				{
					target_insect.die((World)beings);
					target_insect = null;
					//changeGoal(new Int2D(x,y));
				}
				
				// look for a new target
				if (target_insect == null || rand.nextFloat() > probability) 
					this.lookForTarget((World)beings);
				
				//update goal according to insect position
				if (target_insect != null)
					trackTarget((World)beings);
				
				break;
				
			case Propulsed : 
				for(int i =0; i < speed && !onGoal(); i++)
					oneMoveTo(new Int2D(goalX, goalY), (World)beings);
				
				//if the goal is reached, the state goes back to normal
				if(onGoal())
					setState(State.Normal);
				
				break;
			
			default :
				break;
		}

		super.step(beings);
	}
	

	/**
	 * Follow target avoiding the hole (see MIN_DIST constant)
	 */
	private void trackTarget(World beings)
	{
		if(!isReachable(beings, target_insect.x, target_insect.y))
		{
			target_insect = null;
			lookForTarget(beings);
		}
		
		if (target_insect != null) 
			changeGoal(new Int2D(target_insect.x, target_insect.y));
		else
			changeGoal(new Int2D(x,y));
	}
	
	private boolean onTarget(int x, int y)
	{
		return (x>=this.x - monsterWidth && x<=this.x + monsterWidth) && (y>=this.y - monsterHeight && y<=this.y + monsterHeight);
	}
}


class SortByDistance implements Comparator<Insect> {

	@Override
	public int compare(Insect o1, Insect o2) {		
		return o1.x-o2.x+o1.y-o2.y;
	}
	
}