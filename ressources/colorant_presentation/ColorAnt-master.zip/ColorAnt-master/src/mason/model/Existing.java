package mason.model;

import sim.engine.SimState;
import sim.engine.Steppable;
import sim.engine.Stoppable;
import sim.util.Int2D;

/**
 * have some common traits of a existing objects
 * @author Linxuhao
 * @author Elisa Ayala
 */
public abstract class Existing extends Notificator implements Steppable {
	
	//to avoid warnings
	private static final long serialVersionUID = 1L;
	
	/**
	 * mason attribute allowing to stop the object
	 */
	protected Stoppable stoppable;
	
	private boolean isDebuging = false;
	
	/**
	 * an exploding insect will propulse objets in PROPULSING_AREA distance 
	 */
	public static final int PROPULSING_AREA = 100;
	
	public Existing(World world) {
		super();
	}
	
	/**
	 * how many cases with explosive ink to visit to provok explosion of the insect
	 */
	public static final int EXPLOSING_TIME= 2;
	
	/**
	 * the current real position of the insect on x 
	 */
	float realPositionX;
	
	/**
	 * the current real position of the insect on y
	 */
	float realPositionY;
	
	
	/*
	 * put this object in propulsed state
	 * give it an ending location as a goal
	 * according to explosion center
	 */
	public void propulsed(World beings, Int2D explosionCoord)
	{
		if(isDebuging())
		{
			System.out.println("Propulsed");
		}
		
		//if(this instanceof Monster)
		//System.out.println("monster propulsed");
		
		// change state (this might change speed as well)
		setState(State.Propulsed);
		
		// create direction vector representing the vector between this object and the explosion center
		int force = 50; // modify this to change the force of the explosion
		int dirX = this.x - explosionCoord.x;
		int dirY = this.y - explosionCoord.y;
		

		// normalisation
		dirX = (int)Math.round(dirX / Math.sqrt(Math.pow(dirX, 2) + Math.pow(dirY, 2)));
		dirY = (int)Math.round(dirY / Math.sqrt(Math.pow(dirX, 2) + Math.pow(dirY, 2)));
		
		// multiply by force
		Int2D movingVector = new Int2D(dirX * force, dirY * force);
		
		// modifies goal	
		changeGoal(addLocations(beings, new Int2D(this.x, this.y), movingVector));
		
		//notifies observer
		notifyObserver(beings, this);
	}
	
	/*
	 * add 2 locations, staying in world map
	 */
	public Int2D addLocations(World beings, Int2D a, Int2D b)
	{
		int x = a.x + b.x;
		int y = a.y + b.y;
		if (x < 0)	x = 0;
		if (x > beings.getWidth()) x = beings.getWidth();
		if (y < 0)	y = 0;
		if (y > beings.getHeight()) y = beings.getHeight();
		
		return new Int2D(x,y);
	}
	
	/*
	 * use this to modify goal
	 * notifies the notification agent if the goal changed
	 */
	public void changeGoal(Int2D newGoal){
		
		if(goalX != newGoal.x || goalY != newGoal.y)
		{
			goalX = newGoal.x;
			goalY = newGoal.y;
			changed = true; // boolean from notificator mother class
		}
	}
	
	/*
	 * use this to modify speed
	 * notifies the notification agent if the speed changed
	 */
	public void changeSpeed(int newSpeed){
		if(isDebuging()){
			System.out.println("Goal changed");
		}
		
		if(newSpeed != speed)
		{
			speed = newSpeed;
			changed = true; // boolean from notificator mother class
		}
	}
	
	
	/*
	 * changes state
	 * override this to specify special effects (like changing speed)
	 */
	public void setState(State state)
	{
		this.state = state;
		//changed = true; // TODO : uncomment to make sure it's notified on time
	}

	@Override
	public void step(SimState state) {
		World beings = (World) state;
		notifyObserver(beings, this);
	}

	public boolean isDebuging() {
		return isDebuging;
	}

	public void setDebuging(boolean isDebuging) {
		this.isDebuging = isDebuging;
	}
	
	protected void oneMoveTo(Int2D loc, World beings) {
	
		int moveX = loc.x - x;
		int moveY = loc.y - y;
		float norm = (float)Math.sqrt(moveX*moveX + moveY*moveY);
		
		if(norm != 0.0)
		{
			realPositionX += moveX/norm;
			realPositionY += moveY/norm;
			x = (int)Math.floor(realPositionX);
			y = (int)Math.floor(realPositionY);
		}
		
		/*if(isDebuging()){
		  if(this.displayId == 2)
				System.out.println("realPositions : "+ realPositionX + " " + realPositionY);
		
		  }*/
			
		
		beings.getYard().setObjectLocation(this, this.x, this.y);
	}
	
	/**
	 * has the insect reached the goal?
	 */
	protected boolean onGoal()
	{
		if(x == goalX && y == goalY)
			return true;
		return false;
	}
	

	//because Java does not have clamp function
	public int clamp(int val, int min, int max) {
	    //return Math.max(min, Math.min(max, val));
		if(val<min)
			val = min;
		if(val>max)
			val = max;
		return val;
	}
}
