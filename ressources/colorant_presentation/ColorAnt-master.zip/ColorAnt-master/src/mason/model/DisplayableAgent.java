package mason.model;


/**
 * A displayable agent needs a display type to communicate with the front<br>
 * and has x, y as agent position
 * @author Linxuhao
 *
 */
public abstract class DisplayableAgent {
	/**
	 * the unique id to a object
	 */
	protected long displayId;
	/**
	 * current position
	 */
	protected int x,y;
	

	public long getDisplayId() {
		return displayId;
	}

	public void setDisplayId(long displayId) {
		this.displayId = displayId;
	}	

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

}
