package mason.model;

import java.util.Random;

import sim.engine.SimState;
import sim.engine.Steppable;
import sim.engine.Stoppable;
import sim.util.Int2D;

public class InsectGenerator implements Steppable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Stoppable stoppable;
	Random random;
	private int maxInsectNumber = 35;
	public int currentInsectNumber;

	public Stoppable getStoppable() {
		return stoppable;
	}

	public void setStoppable(Stoppable stoppable) {
		this.stoppable = stoppable;
	}

	public InsectGenerator() {
		random = new Random();
		
	}

	@Override
	public void step(SimState state) 
	{
		if(currentInsectNumber < maxInsectNumber && random.nextBoolean() && random.nextBoolean()){
			generateInsect((World)state);
		}
			
	}

	private void generateInsect(World beings) 
	{
		// poping at the center
		float x = (float)beings.getWidth()/2;
		float y = (float)beings.getHeight()/2;
		Int2D location = new Int2D((int)Math.floor(x), (int)Math.floor(y));
		beings.addInsect(location);
		this.currentInsectNumber++;
	}
}
