package mason.model;

import java.awt.Color;

import game.constants.InkType;
import sim.engine.SimState;
import sim.engine.Steppable;
import sim.engine.Stoppable;
import sim.util.Bag;

/**
 * players draws inks !
 * @author Linxuhao
 *
 */
public class Ink extends DisplayableAgent implements Steppable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public static float DEFAULT_AMOUNT = 40;
	public static float DEFAULT_AMOUNT_DECREMENT = 1;

	/**
	 * the type of this ink
	 */
	private InkType type;
	
	/**
	 * the amount of this ink (similar to life)
	 */
	private float amount;
	
	/**
	 * the speed of decrement (amounts points per step)
	 */
	private float decrement;
	
	/**
	 * to stop this agent once is done
	 */
	private Stoppable stoppable;

	/**
	 * Generate a new ink with DisplayObjectType = Ink ! <br>
	 * And set a schedule on it from the world
	 */
	public Ink(World beings, float initialAmount, float amountDecrement,
			int x, int y, InkType type) 
	{
		super();
		this.setDisplayId(beings.generateInkDisplayId());
		//System.out.println("Ink created with amount : " + initialAmount + ", decrement : " + amountDecrement);
		
		this.x = x;
		this.y = y;
		
		this.amount = initialAmount;
		this.decrement = amountDecrement;
		
		this.type = type;

		// remove existing ink at the same location
		Bag bag = beings.getYard().getObjectsAtLocation(x,y);
		if(bag != null)
			for(Object object : bag)
				if(object instanceof Ink && object != this)
					try{
						((Ink) object).stoppable.stop();
						beings.getYard().remove(object);	
					}catch(NullPointerException | ArrayIndexOutOfBoundsException e){
						object = null;
					}
	}
	
	public InkType getType() {
		return type;
	}

	public void setType(InkType type) {
		this.type = type;
	}
	
	@Override
	public void step(SimState state) // todo : debug : it seems that step() is never called
	{
		
		//World beings = (World) state;
		this.amount -= this.decrement;
		
		if (amount <= 0)
		{
			try{
				((World)state).getYard().remove(this);
			}catch(NullPointerException | ArrayIndexOutOfBoundsException e){
				//do nothing
			}finally{
				this.stoppable.stop();
				// only one notif is send when ink is created
				// screen is fading the ink in parallel at the same rate
				// and then will remove it
			}	
		}	
	}

	public float getAmount() {
		return amount;
	}
	
	public void setStoppable(Stoppable s) {
		this.stoppable = s;
	}
	
	
	public Color getColor() {
		switch(this.type){
			case Diriger :
				return Color.GREEN;
			case Exploser :
				return Color.RED;
			case Collecter :
				return Color.YELLOW;
			case Lacher :
				return new Color(139,0,139);
			case Immobiliser :
				return Color.BLACK;
			default :
				return Color.GRAY;	
		}
	}
}
