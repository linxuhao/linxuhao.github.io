package mason.model;

import java.util.ArrayList;
import java.util.List;

import game.constants.ScoringCornerPosition;
import sim.engine.SimState;
import sim.field.grid.SparseGrid2D;
import sim.util.Bag;

public class ScoringCorner extends Existing{

	private PlayerPointer player;

	private int FIELD_WIDTH;
	private int FIELD_HEIGHT;
	
	private int score = 0;
	
	private ScoringCornerPosition position;

	public int getFIELD_WIDTH() {
		return FIELD_WIDTH;
	}

	public int getFIELD_HEIGHT() {
		return FIELD_HEIGHT;
	}

	public int getScore() {
		return score;
	}

	public ScoringCorner(World world, int user) {
		super(world);
		FIELD_WIDTH = (int) (world.getWidth()*0.5);
		FIELD_HEIGHT = (int) (world.getHeight() * 0.5);
		//System.out.println(FIELD_WIDTH);
		setPosition(ScoringCornerPosition.values()[user]);
		
		switch (user) {
		case 0 : 
			x = FIELD_WIDTH/2;
			y = FIELD_HEIGHT/2;
			
			break;
		case 1 :
			x = world.getWidth() - FIELD_WIDTH/2;
			y = FIELD_HEIGHT/2;

			break;
		case 2 :
			y = world.getHeight() - FIELD_HEIGHT/2;
			x = FIELD_WIDTH/2;

			break;
		case 3 :
			x = world.getWidth() - FIELD_WIDTH/2;
			y = world.getHeight() - FIELD_HEIGHT/2;

			break;
		default:
			break;
		}
		//System.out.println(x);
		//System.out.println(y);

	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public void step(SimState beings) {
		World world = (World)beings;
		List<Collectable> cs = perceive(world);
		if(score != cs.size()){
			score = cs.size();
			world.observer.setScoreChanged(true);
		}
	}
	
	
	private List<Collectable> perceive(World beings) 
	{
		List<Collectable> perceivedList = new ArrayList<Collectable>();
		SparseGrid2D grid = beings.getYard();
		
		for(int i = x - FIELD_WIDTH/2; i <= x + FIELD_WIDTH/2; i++)
			for(int j = y - FIELD_HEIGHT/2; j <= y + FIELD_HEIGHT/2; j++)
			{
				Bag objects = grid.getObjectsAtLocation(i,j); 
				if(objects != null)
					for(Object o : objects) 
						if(o instanceof Collectable) {
							Collectable c = (Collectable)o;
							if (!c.isCarried())
								perceivedList.add(c);
						}
			}
		
		return perceivedList;	
	}

	public PlayerPointer getPlayer() {
		return player;
	}

	public void setPlayer(PlayerPointer player) {
		this.player = player;
	}

	public ScoringCornerPosition getPosition() {
		return position;
	}

	public void setPosition(ScoringCornerPosition position) {
		this.position = position;
	}
}
