package mason.model;

import game.constants.InkType;
import game.constants.PlayerPointerIds;
import game.model.GameRoom;
import game.model.Player;
import sim.engine.SimState;
import sim.engine.Stoppable;
import sim.field.grid.SparseGrid2D;
import sim.util.Int2D;

public class World extends SimState {
	
	private static final long serialVersionUID = 1L;
	/**
	 * one seconds in miliseconds
	 */
	private final static int second = 1000;
	/**
	 * game duration in milliseconds 5 mins
	 */
	public final static long GAME_DURATION = 180 * second;
	private long startingTime;

	public long getStartingTime() {
		return startingTime;
	}

	public void setStartingTime(long startingTime) {
		this.startingTime = startingTime;
	}

	private SparseGrid2D yard;
	
	public Observer observer = new Observer();
	
	/**
	 * id generator for objects in this game
	 */
	private long displayIdCount = 1;
	
	private long inkIdCount;
	private int width, height;
	private InsectGenerator  a;
	private GameRoom room;
	
	public World(long seed, int width, int height, GameRoom room) {
		super(seed);
		this.width = width;
		this.height = height;
		this.yard = new SparseGrid2D(this.width,this.height);
		//startingTime = java.lang.System.currentTimeMillis();
		this.room = room;
		this.startingTime = 0;
		inkIdCount = 0;
		displayIdCount = 1;
	}
	
	
	public SparseGrid2D getYard() {
		return yard;
	}


	public void setYard(SparseGrid2D yard) {
		this.yard = yard;
	}


	public int getWidth() {
		return width;
	}


	public void setWidth(int width) {
		this.width = width;
	}


	public int getHeight() {
		return height;
	}


	public void setHeight(int height) {
		this.height = height;
	}

	/**
	 * TODO : add true game init 
	 */
	public void start() {
		System.out.println("Simulation started");
		inkIdCount = 0;
		displayIdCount = 1;
		schedule.reset();
		schedule.clear();
		yard.clear();
	    if(a != null){
	    	a.getStoppable().stop();
	    	a = null;
	    }
	    super.start();
	    
	    //add inks (TODO : remove this)
	    
	    /*for(int i = 0; i < getHeight(); i++)
	    	addInk(InkType.Direction, new Int2D((int)getWidth()/2,i), i, 1);
	    for(int i = 0; i < getHeight(); i++) 
	    {
	    	addInk(InkType.Explosion, new Int2D(i,5), i, 1);
	    	addInk(InkType.Explosion, new Int2D(i,6), i, 1);
	    	addInk(InkType.Explosion, new Int2D(i,7), i, 1);
	    }
	    for(int i = 0; i < getHeight(); i++)
	    	addInk(InkType.Stuck, new Int2D(i,13), 200 - i, 1);
	    	
	    for(int i = 0; i < getHeight(); i++) 
	    {
	    	addInk(InkType.Drop, new Int2D(i,25), i, 1);
	    	addInk(InkType.Drop, new Int2D(i,26), i, 1);
	    	addInk(InkType.Drop, new Int2D(i,27), i, 1);
	    }
	    
	    for(int i = 0; i < getHeight(); i++) 
	    {
	    	addInk(InkType.Get, new Int2D(i,300), 2*i, 1);
	    }*/

	    
	    //addInk(InkType.Explosion, new Int2D(52,50), Ink.DEFAULT_AMOUNT, 1);
	    
	    // add insect generator
	    addInsectGenerator();
	    
	    // add collectables
	   /* addCollectable(new Int2D(60,30));
	    addCollectable(new Int2D(50,30));
	    addCollectable(new Int2D(40,30));
	    addCollectable(new Int2D(20,50));
	    addCollectable(new Int2D(30,40));
	    addCollectable(new Int2D(30,10));*/
	    int collectableNumber = 8;
	    int numberOfCollectablePerLine = 2;
	    int numberOfCollectablePerVerticalLine = collectableNumber / numberOfCollectablePerLine;
	    for(int a = 0; a <= numberOfCollectablePerLine; a++){
	    	 for(int b = 0; b <= numberOfCollectablePerVerticalLine; b++){
	    		 addCollectable(new Int2D(getWidth() / numberOfCollectablePerLine / 2  + getWidth() / numberOfCollectablePerLine * a, getHeight() / numberOfCollectablePerVerticalLine / 2 + getHeight() / numberOfCollectablePerVerticalLine * b));

	 	    }
	    }
	    
	    //add score corners
	    if(room != null){
	    	for(int i = 0; i < room.getPlayers().size(); i++){
		    	Player player = room.getPlayers().get(i);
		    	//if is not a fake player, give him a scoring pointer
		    	if(player.getPositionPointer() != null){
		    		for(PlayerPointerIds playerPointerId : PlayerPointerIds.values()){
		    			if(player.getPointerIcon().equals(playerPointerId.toString())){
		    				player.getPositionPointer().setScoringCorner(addScoringCorner(playerPointerId.ordinal()));
		    			}
		    		}
		    		
		    	}
		    }
	    }else{
	    	//TODO: mason debug only
	    	addScoringCorner(0);
	    	addScoringCorner(1);
	    	addScoringCorner(2);
	    	addScoringCorner(3);
	    }
	    
	    
	    // add monsters
	    addMonster(new Int2D(10,10));
	    addMonster(new Int2D(getWidth()-10,getHeight()-10));
	    addMonster(new Int2D(10,getHeight()-10));
	    addMonster(new Int2D(getWidth()-10,10));
	   
	}
	
	public void startEmpty() {
		System.out.println("Empty started");
		super.start();
	    yard.clear();
	    schedule.clear();
	}

	public void addMonster(Int2D location)
	{ 
		Monster m = new Monster(this, location, generateInkDisplayId());
	    yard.setObjectLocation(m, location.x, location.y);
		  
	    Stoppable stoppable = schedule.scheduleRepeating(m);
	    m.stoppable = stoppable;
	}
	
	public void addCollectable(Int2D location)
	{ 
		Collectable c = new Collectable(this, location);
	    yard.setObjectLocation(c, location.x, location.y);
		  
	    Stoppable stoppable = schedule.scheduleRepeating(c);
	    c.stoppable = stoppable;
	}
	
	public void addInsect(Int2D location)
	{ 
	      Insect a = new Insect(this, location,this.generateDisplayId());
	    		  
	      yard.setObjectLocation(a, location.x, location.y);
	  
	      Stoppable stoppable = schedule.scheduleRepeating(a);
	      a.stoppable = stoppable;
	}
	
	
	public ScoringCorner addScoringCorner(int user)
	{ 
		ScoringCorner a = new ScoringCorner(this, user);

	    yard.setObjectLocation(a, a.getX(), a.getY());
	    
	    Stoppable stoppable = schedule.scheduleRepeating(a);
     	a.stoppable = stoppable;
     	return a;
	}
	
	
	public void addInk(InkType type, Int2D coord, float amount, float decrement)
	{
	      Ink a = new Ink(this,amount,decrement,coord.x,coord.y,type);
	    		  
	      yard.setObjectLocation(a, coord.x, coord.y);
	  
	      Stoppable stoppable = schedule.scheduleRepeating(a);
	      a.setStoppable(stoppable);
	}
	
	public void addInsectGenerator()
	{
	      a  =  new InsectGenerator();      
	      Stoppable stoppable = schedule.scheduleRepeating(a);
	      a.setStoppable(stoppable);
	}
	

	public long generateInkDisplayId() {
		return this.inkIdCount++;
	}
	
	public long generateDisplayId(){
		return this.displayIdCount++;
	}
	
	
	public boolean isGameFinished(){ 
		
		if (room == null)
			return false; // to dev without server
		
		if(room.allPlayersAreReady()){
			return(startingTime + GAME_DURATION < System.currentTimeMillis());
		}else{
			return false;
		}
		
	}

	public InsectGenerator getInsectGenerator() {
		return a;
	}

	public void setInsectGenerator(InsectGenerator a) {
		this.a = a;
	}

	public GameRoom getRoom() {
		return room;
	}

	public void setRoom(GameRoom room) {
		this.room = room;
	}

}
