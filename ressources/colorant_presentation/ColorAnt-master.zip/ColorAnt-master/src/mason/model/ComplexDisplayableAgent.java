package mason.model;

import sim.util.Int2D;

/**
 * A more complex displayable agent with goal and speed
 * @author Linxuhao
 *
 */
public abstract class ComplexDisplayableAgent extends DisplayableAgent{
	
	
	/**
	 * possible states of existing objects
	 */
	public enum State 
	{
		Normal,
		Propulsed,
		Stuck;
	}
	
	/**
	 * current state
	 */
	protected State state = State.Normal;
	/**
	 * Goal position
	 */
	protected int goalX = -1;
	protected int goalY = -1;
	/**
	 * speed, in cases per step
	 */
	protected int speed;

	public int getGoalX() {
		return goalX;
	}

	public void setGoalX(int goalX) {
		this.goalX = goalX;
	}

	public int getGoalY() {
		return goalY;
	}

	public void setGoalY(int goalY) {
		this.goalY = goalY;
	}

	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}

	public State getState() {
		return state;
	}

	public void setState(State state) {
		this.state = state;
	}

	/**
	 * Get agent's heading
	 * @return heading vector
	 */
	public Int2D getHeading() {
		return new Int2D(x-goalX, y-goalY);
	}
}
