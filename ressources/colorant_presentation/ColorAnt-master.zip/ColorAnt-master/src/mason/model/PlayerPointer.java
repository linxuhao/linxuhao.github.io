package mason.model;

import java.util.ArrayList;
import java.util.List;

import game.constants.InkType;
import game.model.Player;
import sim.util.Int2D;

/**
 * A pointer is a object that indicate a player's location
 * @author Linxuhao
 *
 */
public class PlayerPointer extends Notificator {
	
	/**
	 * the player related to this pointer
	 */
	private Player player;
	private InkType currentInkType;
	private ScoringCorner scoringCorner;
	
	public PlayerPointer(World world, Player player, int x, int y) {
		super();
		this.setDisplayId(world.generateDisplayId());
		this.player = player;
		this.x = x;
		this.y = y;
		this.currentInkType = InkType.None;
	}
	
	public Player getPlayer() {
		return player;
	}
	public void setPlayer(Player player) {
		this.player = player;
	}
	
	public InkType getCurrentInkType() {
		return currentInkType;
	}

	public void setCurrentInkType(InkType currentInkType) {
		this.currentInkType = currentInkType;
	}
	
	public void setPositionAndDraw(World world, InkType inkType, int newX, int newY) {
		//System.out.println("new Position is (" + newX + ", " + newY + "), old Position is (" + getX() + ", " + getY() + ")");
		this.currentInkType = inkType;
		//None means no ink selected
		if(inkType != InkType.None){
			List<Int2D> positions = findShortestWayBetweenTwoPositions(x , y, newX, newY);
			//System.out.println("the shortest way is : ");
			//this way, the inks created in the same frame will have different amount, the closest to goal have biiger amount

			for(Int2D position : positions){
				//System.out.println("(" + position.getX() + ", " + position.getY() + ")");
				
				world.addInk(inkType, position, Ink.DEFAULT_AMOUNT, Ink.DEFAULT_AMOUNT_DECREMENT);

			}
		}
		//set new positions
		setX(newX);
		setY(newY);
		world.getYard().setObjectLocation(this, new Int2D(getX(), getY()));
		this.changed = true;
		this.notifyObserver(world, this);
	}

	/**
	 * position head is not included in the way between them <br>
	 * position tail is included
	 * @param x
	 * @param y
	 * @param newX
	 * @param newY
	 * @return
	 */
	private List<Int2D> findShortestWayBetweenTwoPositions(int x, int y, int newX, int newY) {
		List<Int2D> positions = new ArrayList<Int2D>();
		//x, y are primary types, are not pointers, so i can modify them inside this function without affecting x and y of this pointer
		int xDistance = newX - x;
		int yDistance = newY - y;
		int xAdd = findAddValue(xDistance);
		int yAdd = findAddValue(yDistance);
		while(xDistance != 0 || yDistance != 0){
			if(xDistance != 0){
				xDistance -= xAdd;
				x += xAdd;
			}
			if(yDistance != 0){
				yDistance -= yAdd;
				y += yAdd;
			}
			Int2D wayPoint = new Int2D(x,y);
			positions.add(wayPoint);
		}
		return positions;
	}

	private int findAddValue(int distance) {
		int add = 1;
		if(distance < 0){
			add = -1;
		}
		return add;
	}

	public ScoringCorner getScoringCorner() {
		return scoringCorner;
	}

	public void setScoringCorner(ScoringCorner scoringCorner) {
		this.scoringCorner = scoringCorner;
	}
	
}
