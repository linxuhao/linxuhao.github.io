package mason.main;

import sim.display.Console;
import mason.gui.BeingsWithUI;
import mason.model.World;

public class BeingsMain {
	public static void main(String[] args) {
        runUI();
	}
	public static void runUI() {
		World model = new World(System.currentTimeMillis(), 500, 500, null);
		BeingsWithUI gui = new BeingsWithUI(model);
		Console console = new Console(gui);
		console.setVisible(true);
	}
}
