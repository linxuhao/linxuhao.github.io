package helper;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Stack;

import net.glxn.qrgen.core.image.ImageType;
import net.glxn.qrgen.javase.QRCode;
import web.constants.AppInformation;

/**
 * helps generate files, such as QRCode
 * @author Linxuhao
 *
 */
public class FileHelper {
	
	

	/**
	 * Generate a unique file location to save the qrCode generated for this very room <br>
	 * @param roomId
	 * @param appPath is the absolute app path 
	 * @return 
	 * @throws IOException
	 */
	public static String generateQRCodelLocation(String appPath, String roomId) throws IOException {
		Path directoryPath = getQrCodeFolderPath(appPath);
		File directory = directoryPath.toFile();
		if(!directory.exists()){
			Files.createDirectories(directoryPath);
		}
		StringBuilder sb = new StringBuilder();
		sb.append(roomId).append(".").append(AppInformation.QRCODES_FORMAT);
		Path qrCodePath = Paths.get(directory.getAbsolutePath(),sb.toString());
		return qrCodePath.toString();
	}

	/**
	 * get the qrCode folder path
	 * @param appPath
	 * @return
	 */
	public static Path getQrCodeFolderPath(String appPath) {
		return Paths.get(appPath, AppInformation.RESSOURCE_FOLDER, AppInformation.QRCODES_FOLDER);
	}
	
	/**
	 * Generate a unique qrcode based on the unique roomId
	 * @param appPath is the absolute path of this web app in operation system
	 * @param roomId is the unique id of a game room
	 * @param urlToRoom is the unique url To this game Room
	 * @return the qrcode file
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	public static File generateQRCode(String appPath, String roomId, String urlToRoom) throws IOException, FileNotFoundException {
		ByteArrayOutputStream qrCode = QRCode.from(urlToRoom)
				.to(ImageType.PNG).stream();
		//create a file under app folder
		String qrCodeLocation = generateQRCodelLocation(appPath, roomId);	
		File qrCodeFile = new File(qrCodeLocation);
		//write the file
		FileOutputStream fout = new FileOutputStream(qrCodeFile);
		fout.write(qrCode.toByteArray());

		fout.flush();
		fout.close();
		return qrCodeFile;
	}

	/**
	 * return file name of pointer files include extensions
	 * @return
	 */
	public static Stack<String> loadPlayerPointers() {
		Stack<String> pointers = new Stack<String>();
		File pointerFolder = Paths.get(AppInformation.getAppFolderPath(), AppInformation.RESSOURCE_FOLDER, AppInformation.IMAGES_FOLDER, AppInformation.POINTERS_FOLDER).toFile();
		if(pointerFolder.exists()){
			for(File pointerFile : pointerFolder.listFiles()){
				pointers.push(pointerFile.getName());
			}
		}
		return pointers;
	}

}
