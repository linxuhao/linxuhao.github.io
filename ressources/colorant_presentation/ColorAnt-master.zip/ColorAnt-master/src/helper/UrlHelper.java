package helper;

import java.io.File;

import web.constants.AppInformation;
import web.constants.ServletDomains;

/**
 * Helps to generate urls
 * @author Linxuhao
 *
 */
public class UrlHelper {
	
	public static final String roomIdVariableName = "roomid";
	
	/**
	 * generate a unique Url To a game room <br>
	 * @param roomId
	 * @return
	 */
	public static String generateUrlToRoom(String appUrl, String roomId) {
		StringBuilder sb = new StringBuilder();
		sb.append(AppInformation.PROTOCOL).append("://").append(appUrl).append(ServletDomains.GAME).append(AppInformation.URL_SEPARATOR)
		//le ? permet d'indiquer que les choses qui suivent sont des parametres de navigation
		.append("?")
		.append(roomIdVariableName).append("=").append(roomId);
		return sb.toString();
	}
	
	/**
	 * returns the relative file access url in web app
	 * @param qrCodeFile
	 * @return
	 */
	public static String generateUrlToQrCode(File qrCodeFile) {
		StringBuilder sb = new StringBuilder();
		sb.append(AppInformation.URL_SEPARATOR).append(AppInformation.RESSOURCE_FOLDER).append(AppInformation.URL_SEPARATOR)
		.append(AppInformation.QRCODES_FOLDER).append(AppInformation.URL_SEPARATOR).append(qrCodeFile.getName());
		return sb.toString();
	}
	
	/**
	 * generate a unique Url To a game room websocket<br>
	 * @param roomId
	 * @return
	 */
	public static String generateWebsocketUrlToRoom(String appUrl, String roomId) {
		StringBuilder sb = new StringBuilder();
		sb.append(AppInformation.WEBSOCKET_PROTOCOL).append("://").append(appUrl)
		.append(ServletDomains.GAMESOCKET).append("/").append(roomId);
		return sb.toString();
	}
}
