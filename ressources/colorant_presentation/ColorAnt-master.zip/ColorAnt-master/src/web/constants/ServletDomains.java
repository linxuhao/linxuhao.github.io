package web.constants;

import helper.UrlHelper;

/**
 * URL Domains per servlet, is used to avoid spelling errors
 * @author Linxuhao
 *
 */
public class ServletDomains {
	
	public static final String GAME = "/Game";
	public static final String GAME_PATH = "/Game/*";

	public static final String GAMESOCKET = "/GameSocket";
	public static final String GAMESOCKET_PATH = "/GameSocket/{"+ UrlHelper.roomIdVariableName + "}" + "/{username}";
	
}
