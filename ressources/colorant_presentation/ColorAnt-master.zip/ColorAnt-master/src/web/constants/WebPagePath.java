package web.constants;

/**
 * A enum class storing all paths to web page we gonna use in java servlets <br>
 * Is used to avoid spelling errors
 * @author Linxuhao
 *
 */
public enum WebPagePath {
	
	INDEX("/jsps/index.jsp"),
	GAME("/jsps/game.jsp"),
	TUTORIAL("/jsps/tutorial.jsp"),
	PLAYER("/jsps/player.jsp");
	
	String value;
	
	WebPagePath(String value){
		this.value = value;
	}
	
	/**
	 * return the path to the web page
	 * @return
	 */
	public String getValue(){ return this.value; }
	
	/**
	 * return the path to the web page, does the same thing as getValue(), but in case ppl prefers toString methode xD
	 */
	@Override
	public String toString(){ return this.value; }
}
