package web.constants;

import java.io.File;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.Enumeration;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;

/**
 * Class containning crucial informations of this web app
 * @author Linxuhao
 *
 */
public class AppInformation {
	
	private static boolean app_initiated = false;
	
	public static final String CENTRAL_SCREEN_NAME = "CentralScreen";
	
	/**
	 * the folder to store QRCodes
	 */
	public static final String QRCODES_FOLDER = "QRCode";
	/**
	 * the folder to store Ressources
	 */
	public static final String RESSOURCE_FOLDER = "ressources";
	/**
	 * the QRCodes image formats
	 */
	public static final String QRCODES_FORMAT = "png";
	
	/**
	 * the folder to store images
	 */
	public static final String IMAGES_FOLDER = "images";
	/**
	 * the folder to store pointers
	 */
	public static final String POINTERS_FOLDER = "pointers";
	
	public static final String WEBSOCKET_DOMAIN = "websockets";
	public static final String WEBSOCKET_PROTOCOL = "ws";
	/**
	 * Our web app uses http, no way that it goes to https !!!!!!
	 */
	public static final String PROTOCOL = "http";
	public static final String URL_SEPARATOR = "/";
	private static String ip;
	private static int port;
	private static String projectName;
	private static String appFolderPath;
	
	public static String getSelfIp(){
		return ip;
	}

	/**
	 * the port number which this web app uses
	 * @return
	 */
	public static int getPort() {
		return port;
	}

	/**
	 * This web app's name, yes i can read it on run time, but i still put a constant here xD
	 * @return
	 */
	public static String getProjectName() {
		return projectName;
	}

	/**
	 * return the root url of this web app as " 192.168.1.1:8080/YourWebApp"
	 * @return
	 */
	public static String getAppUrl(){
		StringBuilder sb = new StringBuilder();
		sb.append(getSelfIp()).append(":").append(getPort()).append(AppInformation.URL_SEPARATOR).append(getProjectName());
		return sb.toString();
	}
	
	/**
	 * return the root url of this web app as " 192.168.1.1:8080/YourWebApp"
	 * @return
	 */
	public static String getHostWithPort(){
		StringBuilder sb = new StringBuilder();
		sb.append(getSelfIp()).append(":").append(getPort());
		return sb.toString();
	}

	public static boolean isApp_initiated() {
		return app_initiated;
	}

	public static void setApp_initiated(boolean app_initiated) {
		AppInformation.app_initiated = app_initiated;
	}
	
	public static void initAppInformations(HttpServlet servlet, HttpServletRequest request){
		
		port = request.getLocalPort();
		ip = findWorkingIp().replace(URL_SEPARATOR, "");
		appFolderPath = servlet.getServletContext().getRealPath(File.separator);
		projectName = request.getContextPath().replace(URL_SEPARATOR, "");
		setApp_initiated(true);	
		
	}

	/**
	 * @return  a true working ip if you have internet connection, else it may return a virtual machine ip
	 */
	private static String findWorkingIp() {
		//if efficient way work, is good, returns the right ip
		//efficient way to do it, but it requires internet and google server responding xD
		Socket socket= new Socket();
	    try {
	    	SocketAddress endpoint= new InetSocketAddress("www.google.com", 80);
			socket.connect(endpoint);
		    InetAddress localAddress = socket.getLocalAddress();
		    socket.close();
		    //return the ip
		    return localAddress.toString();
		} catch (Exception e) {
			System.out.println("Server has no internet connection !!!! the ip detection could get the wrong ip such as a virtual machine ip");
			e.printStackTrace();
			//if efficient way is not working hope we can get the right ip
		    // not efficient way, because it can mistake the virtual machine ip to your true ip
			return findWorkingIpWithoutInternet();
		}
	}

	/**
	 * 
	 * @return null if no adresse found, may return a virtual machine ip
	 */
	private static String findWorkingIpWithoutInternet() {
		String ipAdresse = null;
		try {
			Enumeration<NetworkInterface> nets = NetworkInterface.getNetworkInterfaces();
			while(nets.hasMoreElements()){
				NetworkInterface netwokInterface = nets.nextElement();
				if(!netwokInterface.isLoopback() && !netwokInterface.isVirtual()
						&& netwokInterface.isUp() && !netwokInterface.getDisplayName().equalsIgnoreCase("virtual")){
					Enumeration<InetAddress> adresses = netwokInterface.getInetAddresses();
					while(adresses.hasMoreElements()){
						InetAddress adresse = adresses.nextElement();
						if(adresse instanceof Inet4Address){
							//return the ip
							ipAdresse =  adresse.getHostAddress();
						}
					}
				}
			}
		} catch (Exception e2) {
			e2.printStackTrace();
		}
		return ipAdresse;
		
	}

	public static String getAppFolderPath() {
		return appFolderPath;
	}

	public static void setAppFolderPath(String appFolderPath) {
		AppInformation.appFolderPath = appFolderPath;
	}
}
