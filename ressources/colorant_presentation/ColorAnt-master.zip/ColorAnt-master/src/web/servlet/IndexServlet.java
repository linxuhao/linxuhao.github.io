package web.servlet;


import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import web.constants.AppInformation;
import web.constants.WebPagePath;

/**
 * Servlet handling the root page, the "" is @WebServlet("") is the url path to this page
 * @author Linxuhao
 */
@WebServlet("")
public class IndexServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
       
    public IndexServlet() {
        super();
    }
    /**
	 * get the web page from local path, returns it to the http request user
     * @throws IOException 
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException{
		try {
			if(!AppInformation.isApp_initiated()){
				AppInformation.initAppInformations(this, request);
			}
			RequestDispatcher view = request.getRequestDispatcher(WebPagePath.INDEX.getValue());
			view.forward(request,response);
		} catch (Exception e) {
			e.printStackTrace();
			response.sendError(500, e.getMessage());
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{
		doGet(request, response);
	}

}
