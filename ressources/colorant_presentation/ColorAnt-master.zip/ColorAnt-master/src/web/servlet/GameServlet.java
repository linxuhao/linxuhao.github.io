package web.servlet;

import java.io.File;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;

import game.GameRoomHandler;
import game.GameRunnerThread;
import game.constants.InkType;
import game.model.GameRoom;
import helper.FileHelper;
import helper.UrlHelper;
import mason.model.Ink;
import mason.model.World;
import web.constants.*;

/**
 * 
 * @author Linxuhao
 */
@WebServlet(ServletDomains.GAME_PATH)
public class GameServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
       
    public GameServlet() {
        super();
    }

    /**
     * Connexion for palyers
     * @param request
     * @param response
     * @throws IOException 
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException{
    	String roomId = null;
    	try {
    		roomId = request.getParameter(UrlHelper.roomIdVariableName).trim();
    	} catch (Exception e) {
			//e.printStackTrace();
    		System.out.println("someone tried to join a room without a room id");
			response.sendError(403, "------------------Please specify a room id to join------------------");
		}
    	if(roomId != null){
    		try{
        		GameRoom room = GameRoomHandler.gamerooms.get(roomId);
        		if(room != null){
        			String appUrl = AppInformation.getAppUrl();
        			String websocketUrl = UrlHelper.generateWebsocketUrlToRoom(appUrl, roomId);
        			ObjectMapper mapper = new ObjectMapper();
        			
            		String inkTypes = mapper.writeValueAsString(InkType.values());
        			
            		request.setAttribute(UrlHelper.roomIdVariableName, roomId);
            		request.setAttribute("username", "player");
        			request.setAttribute("websocketUrl", websocketUrl);
        			request.setAttribute("inkTypes", inkTypes);
        			request.setAttribute("mapHeight", room.getGame().getHeight());
        			request.setAttribute("mapWidth", room.getGame().getWidth());
        			
        			RequestDispatcher view = request.getRequestDispatcher(WebPagePath.PLAYER.getValue());	
        			view.forward(request,response);
        		}else{
        			response.sendError(403, "------------------The room you are trying to access does not exist------------------");
        		}
        	} catch (Exception e) {
    			e.printStackTrace();
    			response.sendError(500, e.getMessage());
    		}
    	}
    }
    
    /**
     * Connexion for the room master (the central screen)
     * @param request
     * @param response
     * @throws IOException 
     */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{
		try {
			//check app initiated, if not, init it
			if(!AppInformation.isApp_initiated()){
				AppInformation.initAppInformations(this, request);
			}
			
			String roomname = request.getParameter("roomname").trim();

			String appUrl = AppInformation.getAppUrl();
			//generate room id
			String roomId = GameRoomHandler.generateRoomId(roomname);
			//generate QrCode
			String urlToRoom = UrlHelper.generateUrlToRoom(appUrl, roomId);
			String websocketUrl = UrlHelper.generateWebsocketUrlToRoom(appUrl, roomId);
			//get app path
			File qrCodeFile = FileHelper.generateQRCode(AppInformation.getAppFolderPath(), roomId, urlToRoom);
			//Create a room and put it in the handler, this step is not supposed to have error, because room id is ensured to be unique !!!
			GameRoom room = new GameRoom(roomId,qrCodeFile, 500,500);
			GameRoomHandler.gamerooms.put(room.getId(), room);
			
			//get the newly created file url
			String qrCodeUrl = UrlHelper.generateUrlToQrCode(qrCodeFile);
			
			//set attributes to be used in jsp file
			request.setAttribute(UrlHelper.roomIdVariableName, roomId);
			request.setAttribute("username", AppInformation.CENTRAL_SCREEN_NAME);
			request.setAttribute("urlToRoom", urlToRoom);
			request.setAttribute("qrCodeLocation", qrCodeUrl);
			request.setAttribute("websocketUrl", websocketUrl);
			request.setAttribute("maxPlayerNumber", room.getMaxPlayerNumber());
			request.setAttribute("mapHeight", room.getGame().getHeight());
			request.setAttribute("mapWidth", room.getGame().getWidth());
			request.setAttribute("tutorial", WebPagePath.TUTORIAL.getValue());
			request.setAttribute("inkDefaultAmount", Ink.DEFAULT_AMOUNT);
			request.setAttribute("inkLvlDecrement", Ink.DEFAULT_AMOUNT_DECREMENT);
			request.setAttribute("noInk", InkType.None.toString());
			request.setAttribute("pointerIconList", room.findAvailablesPointerIcons());
			request.setAttribute("fps", 1000/(GameRunnerThread.gameRunningTimmer * GameRunnerThread.refreshTimmerInMili));
			//System.out.println("fps : " + 1000/(GameRunnerThread.gameRunningTimmer * GameRunnerThread.refreshTimmerInMili));
			request.setAttribute("endTimmer", GameRunnerThread.gameEndingTimmer);
			request.setAttribute("gameDuration", World.GAME_DURATION);
			
			RequestDispatcher view = request.getRequestDispatcher(WebPagePath.GAME.getValue());	
			view.forward(request,response);
		} catch (Exception e) {
			e.printStackTrace();
			response.sendError(500, e.getMessage());
		}
	}

	

}
