package web.servlet;

import java.io.IOException;

import javax.websocket.CloseReason;
import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import game.GameRoomHandler;
import game.message.*;
import game.message.playerToServer.ForceStartMessage;
import game.message.playerToServer.MoveMessage;
import game.message.playerToServer.PlayerToServerMessage;
import game.message.playerToServer.ReadyMessage;
import game.message.playerToServer.RestartMessage;
import game.model.*;
import helper.UrlHelper;
import web.constants.*;

@ServerEndpoint(ServletDomains.GAMESOCKET_PATH)
public class GameSocket {

	private ObjectMapper mapper = new ObjectMapper();
	
    @OnMessage
    public void onMessage(String message, Session session) {
    	SocketMessage socketMessage = deserializeSocketMessage(message);
		if(socketMessage != null){
			switch(socketMessage.getType()){
				case PlayerToServer :  
					handlePlayerMessage(socketMessage.getContent(), session);
					break;
				case CentralScreenToServer : 
					handleCentralScreenMessage(socketMessage.getContent(), session);
					break;
				default :
					break;
	    	}
		}
    }

    /**
     * TODO : delete this todo at the end of project and check if there is message from central screen to server
     * @param content
     */
	private void handleCentralScreenMessage(String content, Session session) {
	}

	/**
	 * handle move request from players
	 * @param content
	 */
	private void handlePlayerMessage(String content, Session session) {
		PlayerToServerMessage message = deserializePlayerMessage(content);
		if(message != null){
			String roomid = (String) session.getUserProperties().get(UrlHelper.roomIdVariableName);
	        GameRoom room = GameRoomHandler.gamerooms.get(roomid);
	        Player player = room.findPlayerBySession(session);
	        
			if(message instanceof MoveMessage){
				MoveMessage moveMessage = (MoveMessage) message;
		        player.moveToPositionAndDraw(room.getGame(), moveMessage.getxMove(), moveMessage.getyMove(), moveMessage.getInk());
			}
			
			if(message instanceof ReadyMessage){
				ReadyMessage readyMessage = (ReadyMessage) message;
				if(readyMessage.isReady()){
					//reset game duration timmer in order to have the best accurate duration
					if(!room.allPlayersAreReady()){
						room.getGame().setStartingTime(System.currentTimeMillis());
					}
					player.setReady(readyMessage.isReady());
					//if there is a fake player, means game is force started, no more ready message to send
					if(room.allPlayersAreReady() && !room.getPlayers().stream().anyMatch(fakeplayer -> fakeplayer.getSocketSession() == null)){
						room.getGameRunnerThread().sendAllPlayersReadyMessage();
		        	}
		        }
			}
			
			if(message instanceof ForceStartMessage){
				ForceStartMessage forceMessage = (ForceStartMessage) message;
				if(forceMessage.isForceStart()){
					room.forceStartTheGame();
					if(room.allPlayersAreReady()){
						room.getGameRunnerThread().sendAllPlayersReadyMessage();
		        	}
		        }
			}
			
			if(message instanceof RestartMessage){
				RestartMessage restartMessage = (RestartMessage) message;
				if(restartMessage.isRestart()){
					player.setRequestRestart(restartMessage.isRestart());
					if(room.allPlayersRequestRestart()){
						room.getGameRunnerThread().sendGameRestartMessage();
						room.restartTheGame();
		        	}
		        }
			}
		} 
	}

	private PlayerToServerMessage deserializePlayerMessage(String content) {
		PlayerToServerMessage message = null;
		try {
			//try to convert to move message
			message = mapper.readValue(content, MoveMessage.class);
		} catch (JsonParseException | JsonMappingException e) {
			//if fail, try to convert to move message
			try{
				message = mapper.readValue(content, ReadyMessage.class);
			}catch (JsonParseException | JsonMappingException e1) {
				//if fail try to convert to ready start message
				try{
					message = mapper.readValue(content, ForceStartMessage.class);
				}catch (JsonParseException | JsonMappingException e2) {
					//if fail try to convert to force start message
					try{
						message = mapper.readValue(content, RestartMessage.class);
					}catch (JsonParseException | JsonMappingException e3) {
						//if fail try to convert to restart message
					
					}catch(IOException e3) {
						//if another exception, print it out
						e.printStackTrace();
					}
				}catch(IOException e2) {
					//if another exception, print it out
					e.printStackTrace();
				}
			}catch(IOException e1) {
				//if another exception, print it out
				e.printStackTrace();
				}
		} catch (IOException e) {
			//if another exception, print it out
			e.printStackTrace();
		}
		return message;
	}

	private SocketMessage deserializeSocketMessage(String message) {
		SocketMessage socketMessage = null;
		try {
			socketMessage = mapper.readValue(message, SocketMessage.class);
		} catch (JsonParseException e1) {
			e1.printStackTrace();
		} catch (JsonMappingException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		return socketMessage;
	}
 
	
    @OnOpen
    public void OnOpen(Session session, @PathParam(UrlHelper.roomIdVariableName) String roomid, @PathParam("username") String username) throws IOException {
    	//store roomid in player websocket session
    	session.getUserProperties().put(UrlHelper.roomIdVariableName, roomid);
        GameRoom room = GameRoomHandler.gamerooms.get(roomid);
    	if(room != null){
    		//if is the central screen, add the screen in game room
            if(username.equals(AppInformation.CENTRAL_SCREEN_NAME)){
            	//add central screen in game room
            	Screen screen = new Screen();
            	screen.setRoomId(roomid);
            	screen.setSocketSession(session);
            	room.getScreens().add(screen);
            }else{
            	//if is a player, add him to his game room as requested
            	Player player = room.addPlayerAndSetUpPointer(room.getGame(), session);
            	if(player != null){
            		//if all players are arrived, start the tutorial phase
        			if(!room.isGameReady()){
        				room.updateGameReady();
        			}
        			//update current player informations
        			room.getGameRunnerThread().sendPlayersInfosMessage();
        			room.getGameRunnerThread().sendPlayerPointer(player);
            	}
    			
            }
            //if game is not started in free painting mode, start it
            if(!room.isGameStarted()){
        		room.startGame();
        	}
        }else{
        	throw new IOException("Room with id : " + roomid + " does not exist");
        }
    }
    
 
    @OnClose
    public void OnClose(CloseReason reason, Session session) {
        
        String roomid = (String) session.getUserProperties().get(UrlHelper.roomIdVariableName);
        GameRoom room = GameRoomHandler.gamerooms.get(roomid);
        String name;
        Player player = room.findPlayerBySession(session);
        //it can be a screen disconnecting
        if(player == null){
        	Screen screen = room.findScreenBySession(session);
        	name = screen.getRoomId() + "'s central screen";
            room.removeScreenBySession(session);
            System.out.println("lost connection with screen, closing game");
            room.closeGame();
        }else{
        	name = player.getRoomId() + player.getSocketSession() != null ? player.getSocketSession().getId() : "fake";
            room.removePlayerBySession(session);
            //update current player informations
			room.getGameRunnerThread().sendPlayersInfosMessage();
			//if there are no real players in game room anymore
			if(!room.getPlayers().stream().anyMatch(realplayer -> realplayer.getSocketSession() != null)){
				System.out.println("no real player in game, closing game");
				room.closeGame();
			}
        }
        System.out.println("Closing a WebSocket for player : " + name + ", withsession id : " + session.getId() + " due to " + reason.getReasonPhrase());
    }
	 
	
}
