package game.message.playerToServer;

/**
 *
 * Message from player to server to indicate player being ready
 * @author Linxuhao
 *
 */
public class RestartMessage implements PlayerToServerMessage{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private boolean restart;

	public boolean isRestart() {
		return restart;
	}

	public void setRestart(boolean restart) {
		this.restart = restart;
	}

}
