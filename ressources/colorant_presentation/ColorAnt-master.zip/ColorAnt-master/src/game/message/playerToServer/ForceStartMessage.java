package game.message.playerToServer;

/**
 *
 * Message from player to server to indicate player being ready
 * @author Linxuhao
 *
 */
public class ForceStartMessage implements PlayerToServerMessage{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private boolean forceStart;

	public boolean isForceStart() {
		return forceStart;
	}

	public void setForceStart(boolean forceStart) {
		this.forceStart = forceStart;
	}

}
