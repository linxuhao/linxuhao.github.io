package game.message.playerToServer;

import java.io.Serializable;

/**
 * Interface for Message from player to server
 * @author Linxuhao
 *
 */
public interface PlayerToServerMessage extends Serializable{

}
