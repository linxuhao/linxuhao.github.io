package game.message.playerToServer;

import game.constants.InkType;

/**
 *
 * Message from player to server to indicate player move
 * @author Linxuhao
 *
 */
public class MoveMessage implements PlayerToServerMessage{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * the relative move that the player did
	 */
	private int xMove, yMove;
	
	/**
	 * null if is not drawing
	 */
	private InkType ink;

	public InkType getInk() {
		return ink;
	}

	public void setInk(InkType ink) {
		this.ink = ink;
	}

	public int getxMove() {
		return xMove;
	}

	public void setxMove(int xMove) {
		this.xMove = xMove;
	}

	public int getyMove() {
		return yMove;
	}

	public void setyMove(int yMove) {
		this.yMove = yMove;
	}
}
