package game.message;

/**
 * a signal tell players and screens that the game has reached end state
 * @author Linxuhao
 *
 */
public class GameEndMessage implements ServerMessage{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private boolean gameEnd;

	public boolean isGameEnd() {
		return gameEnd;
	}

	public void setGameEnd(boolean gameEnd) {
		this.gameEnd = gameEnd;
	}

}
