package game.message.serverToCentralScreen;

import java.util.ArrayList;
import java.util.List;

import mason.model.DisplayableAgent;

/**
 * Message to update game objects in display
 * @author Linxuhao
 *
 */
public class GameContentMessage implements ServerToCentralScreenMessage{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// liste de notifications
	private List<DisplayableAgent> playerList;
	private List<DisplayableAgent> insectList;
	//not sending ink list in new system, TODO : delete ink list when finish project
	//private List<DisplayableAgent> inkList;
	private List<DisplayableAgent> monsterList;
	private List<DisplayableAgent> collectableList;
	private List<Long> deadInsectIdList;
	private List<Long> explosions;
	//tell screen if is a mason step message or not 
	private boolean masonStep;
	
	public GameContentMessage(){
		playerList = new ArrayList<DisplayableAgent>();
		insectList = new ArrayList<DisplayableAgent>();
		//inkList = new ArrayList<DisplayableAgent>();
		monsterList = new ArrayList<DisplayableAgent>();
		collectableList = new ArrayList<DisplayableAgent>();
		deadInsectIdList = new ArrayList<Long>(); 
		explosions = new ArrayList<Long>();  
	}

	public List<DisplayableAgent> getPlayerList() {
		return playerList;
	}

	public void setPlayerList(List<DisplayableAgent> playerList) {
		this.playerList = playerList;
	}

	public List<DisplayableAgent> getInsectList() {
		return insectList;
	}

	public void setInsectList(List<DisplayableAgent> insectList) {
		this.insectList = insectList;
	}

	/*public List<DisplayableAgent> getInkList() {
		return inkList;
	}

	public void setInkList(List<DisplayableAgent> inkList) {
		this.inkList = inkList;
	}*/

	public List<DisplayableAgent> getMonsterList() {
		return monsterList;
	}

	public void setMonsterList(List<DisplayableAgent> monsterList) {
		this.monsterList = monsterList;
	}

	public List<DisplayableAgent> getCollectableList() {
		return collectableList;
	}

	public void setCollectableList(List<DisplayableAgent> collectableList) {
		this.collectableList = collectableList;
	}

	public List<Long> getDeadInsectIdList() {
		return deadInsectIdList;
	}

	public void setDeadInsectIdList(List<Long> deadInsectIdList) {
		this.deadInsectIdList = deadInsectIdList;
	}

	public boolean isMasonStep() {
		return masonStep;
	}

	public void setMasonStep(boolean masonStep) {
		this.masonStep = masonStep;
	}

	public List<Long> getExplosions() {
		return explosions;
	}

	public void setExplosions(List<Long> explosions) {
		this.explosions = explosions;
	}
	
}
