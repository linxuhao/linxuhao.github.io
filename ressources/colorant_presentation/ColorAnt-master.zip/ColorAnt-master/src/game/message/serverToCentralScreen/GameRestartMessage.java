package game.message.serverToCentralScreen;


/**
 * Message to restart a  game when it ends
 * @author Linxuhao
 *
 */
public class GameRestartMessage implements ServerToCentralScreenMessage{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private boolean restart;
	
	public boolean isRestart() {
		return restart;
	}
	public void setRestart(boolean restart) {
		this.restart = restart;
	}

}
