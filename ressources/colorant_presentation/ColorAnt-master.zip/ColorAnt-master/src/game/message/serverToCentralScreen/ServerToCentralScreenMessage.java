package game.message.serverToCentralScreen;

import game.message.ServerMessage;

/**
 * Server sends message to central screen
 * @author Linxuhao
 *
 */
public interface ServerToCentralScreenMessage extends ServerMessage{

}
