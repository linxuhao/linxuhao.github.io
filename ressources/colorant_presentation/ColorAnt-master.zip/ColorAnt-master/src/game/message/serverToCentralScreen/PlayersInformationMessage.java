package game.message.serverToCentralScreen;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import game.constants.ScoringCornerPosition;
import game.model.Player;

/**
 * to update informations about players
 * @author Linxuhao
 *
 */
public class PlayersInformationMessage implements ServerToCentralScreenMessage{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public class PlayerInformation{
		
		public long displayId;
		public String pointer;
		public int score;
		public ScoringCornerPosition scoringCornerPosition;
		
		public PlayerInformation(long displayId, String pointer, int score, ScoringCornerPosition scoringCornerPosition) {
			super();
			this.displayId = displayId;
			this.pointer = pointer;
			this.score = score;
			this.scoringCornerPosition = scoringCornerPosition;
		}
	}
	
	private List<PlayerInformation> infos;

	
	
	public PlayersInformationMessage() {
		super();
		this.infos = new ArrayList<PlayerInformation>();
	}

	public List<PlayerInformation> getInfos() {
		return infos;
	}

	public void setInfos(List<PlayerInformation> infos) {
		this.infos = infos;
	}
	
	public void adaptMessageContents(List<Player> players){
		this.infos = players.stream().map(player -> {
			long displayId;
			int score;
			ScoringCornerPosition position;
			score = 0;
			position = null;
			
			if(player.getPositionPointer() != null){
				displayId = player.getPositionPointer().getDisplayId();
				
				if(player.getPositionPointer().getScoringCorner() != null){
					score = player.getPositionPointer().getScoringCorner().getScore();
					position = player.getPositionPointer().getScoringCorner().getPosition();
				}
			}else{
				displayId = -1;
			}
			return new PlayerInformation(displayId, player.getPointerIcon(),  score, position);
			
		}).collect(Collectors.toList());
	}
}
