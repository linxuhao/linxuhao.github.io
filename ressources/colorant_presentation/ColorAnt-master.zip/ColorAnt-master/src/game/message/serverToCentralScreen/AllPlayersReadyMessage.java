package game.message.serverToCentralScreen;

public class AllPlayersReadyMessage implements ServerToCentralScreenMessage{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * if all players are ready to close the tutorial and play the game
	 */
	private boolean allPlayersReady;
	
	public boolean isAllPlayersReady() {
		return allPlayersReady;
	}
	public void setAllPlayersReady(boolean allPlayersReady) {
		this.allPlayersReady = allPlayersReady;
	}

}
