package game.message.serverToCentralScreen;


/**
 * Message to update game state in display
 * @author Linxuhao
 *
 */
public class GameReadyMessage implements ServerToCentralScreenMessage{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * tell if the game is ready
	 */
	private boolean gameReady;
	
	public boolean isGameReady() {
		return gameReady;
	}
	public void setGameReady(boolean gameReady) {
		this.gameReady = gameReady;
	}


}
