package game.message;

import java.io.Serializable;

/**
 * Mothe class of all messages sent from server
 * @author Linxuhao
 *
 */
public interface ServerMessage extends Serializable{

}
