package game.message;

import java.io.Serializable;

import game.constants.SocketMessageType;

/**
 * The message that will traval between sockets
 * @author Linxuhao
 *
 */
public class SocketMessage implements Serializable{
	
	/**		
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private SocketMessageType type;
	
	private String content;
	
	public SocketMessage() {
		super();
	}

	public SocketMessageType getType() {
		return type;
	}

	public void setType(SocketMessageType type) {
		this.type = type;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
}
