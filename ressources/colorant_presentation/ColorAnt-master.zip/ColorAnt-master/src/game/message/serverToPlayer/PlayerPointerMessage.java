package game.message.serverToPlayer;


public class PlayerPointerMessage implements ServerToPlayerMessage{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String pointer;

	public String getPointer() {
		return pointer;
	}

	public void setPointer(String pointer) {
		this.pointer = pointer;
	}


}
