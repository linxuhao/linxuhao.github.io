package game.message.serverToPlayer;

import game.message.ServerMessage;

public interface ServerToPlayerMessage extends ServerMessage{

}
