package game.message.serverToPlayer;
/**
 * Signal message asking player pages if playre are ready
 * @author Linxuhao
 *
 */
public class PlayerReadyCheckMessage implements ServerToPlayerMessage{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private boolean onCheck;
	
	public PlayerReadyCheckMessage(){
		this.onCheck = true;
	}

	public boolean isOnCheck() {
		return onCheck;
	}

	public void setOnCheck(boolean onCheck) {
		this.onCheck = onCheck;
	}

}
