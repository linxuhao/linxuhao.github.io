package game;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.websocket.Session;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import game.message.GameEndMessage;
import game.message.ServerMessage;
import game.message.serverToCentralScreen.AllPlayersReadyMessage;
import game.message.serverToCentralScreen.GameContentMessage;
import game.message.serverToCentralScreen.GameReadyMessage;
import game.message.serverToCentralScreen.GameRestartMessage;
import game.message.serverToCentralScreen.PlayersInformationMessage;
import game.message.serverToPlayer.PlayerPointerMessage;
import game.message.serverToPlayer.PlayerReadyCheckMessage;
import game.model.*;
import game.model.display.CollectableDisplayObject;
import game.model.display.InsectDisplayObject;
import game.model.display.MonsterDisplayObject;
import game.model.display.PlayerPointerDisplayObject;
import mason.model.*;

/**
 * A thread that run and notify game update to all screens in a game room every refreshTimmerInMili miliseconds
 * @author Linxuhao
 *
 */
public class GameRunnerThread implements Runnable{
	
	/**
	 * refresh the display every time in mili Seconds
	 */
	public static long refreshTimmerInMili = 80;
	/**
	 * how many refresh timer needs to refresh game content once
	 */
	public static int gameRunningTimmer = 2;
	/**
	 * if game is end for 1 mins and no restart requested, game closes
	 */
	public static long gameEndingTimmer = 60000;
	private GameRoom room;
	private boolean running;
	/**
	 * count game end time in system milis
	 */
	private long gameEndTime;
	private boolean masonStep;
	public int endCount = 0;
	
	public GameRunnerThread(GameRoom room){
		this.room = room;
		running = false;
		gameEndTime = 0;
		masonStep = false;
	}
	
	public GameRoom getRoom() {
		return room;
	}

	public void setRoom(GameRoom room) {
		this.room = room;
	}

	public boolean isRunning() {
		return running;
	}

	public void setRunning(boolean running) {
		this.running = running;
	}
	
	public void stop(){
		this.running = false;
	}
	
	@Override
	public void run() {
		running = true;
		int count = 0;
		long timeToRun = System.currentTimeMillis();
		while(isRunning()){
			try {
				if(!room.isGameEnd() && timeToRun <= System.currentTimeMillis()){
					timeToRun += refreshTimmerInMili;
					//reset game end time when game restarted
					if(gameEndTime != 0){
						gameEndTime = 0;
					}
					
					count++;
					if(count > gameRunningTimmer){
						count = 0;
					}
					//if game is ready, run cycle is ready, and all players have voted to close the tutorial, then game begins
					if(room.isGameReady() && count == gameRunningTimmer && room.allPlayersAreReady()){
						runOneStep();
						/*//debug tesing game end
						endCount++;
						if(endCount >= 100){
							endCount = 0;
							room.setGameEnd(true);
							sendGameEndMessage();
						}*/
					}
					//if game is ready but not all players are ready, means we are in tutorial, not pushing game infos
					if(room.isGameReady() && !room.allPlayersAreReady()){
						//not sending in tutorial mode
					}else{
						pushGameToScreenOnNotification();
					}
					
					//if game is finished, put the game in end
					if(room.getGame().isGameFinished()){
						room.setGameEnd(true);
						sendGameEndMessage();
					}
				}else{
					//if game is end, set the game end time and send game end message
					if(gameEndTime == 0){
						gameEndTime = System.currentTimeMillis();
					}
					//if current time is bigger than end time + ending timmer means the waiting time has elapsed, closing the game
					if(System.currentTimeMillis() > gameEndTime + gameEndingTimmer){
						room.closeGame();
					}
					pushGameToScreenOnNotification();
				}
				
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

	private void pushGameToScreenOnNotification() {
		if(room.getGame().observer.isScoreChanged()){
			sendPlayersInfosMessage();
		}
		//send information to all screens if in waiting or gaming mode
		if(room.getGame().observer.haveNotification()){
			String gameInfo = transformGameToDisplayString(room.getGame());
			//clear notifications once get all of them
			room.getGame().observer.clear();
			//System.out.println("Gameinfo : " + gameInfo);
			pushToAllScreens(gameInfo);
		}
		masonStep = false;
	}

	private void runOneStep() {
		masonStep = true;
		room.getGame().schedule.step(room.getGame());
	}

	private void pushToAllScreens(String message){
		List<Screen> screens = room.getScreens();
		try {
			for(Screen screen : screens){
				if(screen.getSocketSession().isOpen()){
					//System.out.println("Get socket session : " + message);
					synchronized(screen.getSocketSession()){
						screen.getSocketSession().getBasicRemote().sendText(message);
					}
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private void pushToAllPlayers(String message){
		room.getPlayers().stream().filter(player -> player.getSocketSession() != null)
		.forEach(player -> {
			if(player.getSocketSession().isOpen()){
				try {
					synchronized(player.getSocketSession()){
						player.getSocketSession().getBasicRemote().sendText(message);
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		});
	}
	

	private void pushToSession(Session socketSession, String message) {
		if(socketSession != null){
			try {
				socketSession.getBasicRemote().sendText(message);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	private String transformGameToDisplayString(World game) {
		//transform mason map into object array
		GameContentMessage message = new GameContentMessage();
		message.setMasonStep(masonStep);
		message.setPlayerList(agentMapToObjectList(game.observer.getPlayer(), playerAgentToObject));
		message.setInsectList(agentMapToObjectList(game.observer.getInsect(), insectAgentToObject));
		message.setMonsterList(agentMapToObjectList(game.observer.getMonster(), monsterAgentToObject));
		//message.setInkList(agentMapToObjectList(game.observer.getInk(), inkAgentToObject));
		message.setCollectableList(agentMapToObjectList(game.observer.getCollectable(), collectableAgentToObject));
		message.setDeadInsectIdList(game.observer.getDeadInsects().stream().collect(Collectors.toList()));
		message.setExplosions(game.observer.getExplosions().stream().collect(Collectors.toList()));
		ObjectMapper mapper = new ObjectMapper();
		String messageString = null;
		try {
			messageString = mapper.writeValueAsString(message);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
				
		return messageString;
	}
	
	/**
	 * java 8 functional interface example !
	 * take a displayableagent as parameter and output a displayObject
	 */
	Function<DisplayableAgent, DisplayableAgent> playerAgentToObject= (agent)-> {
		PlayerPointer pointer = (PlayerPointer) agent;
		return new PlayerPointerDisplayObject(pointer,pointer.getCurrentInkType());
	};
	
	/**
	 * java 8 functional interface example !
	 * take a displayableagent as parameter and output a displayObject
	 */
	Function<DisplayableAgent, DisplayableAgent> insectAgentToObject= (agent)-> {
		Insect insect = (Insect) agent;
		InsectDisplayObject object = new InsectDisplayObject(insect);
		return object;
	};
	
	/**
	 * java 8 functional interface example !
	 * take a displayableagent as parameter and output a displayObject
	 */
	Function<DisplayableAgent, DisplayableAgent> monsterAgentToObject= (agent)-> {
		Monster monster = (Monster) agent;
		MonsterDisplayObject object = new MonsterDisplayObject(monster);
		return object;
	};
		
	/**
	 * java 8 functional interface example !
	 * take a displayableagent as parameter and output a displayObject
	 */
	/*Function<DisplayableAgent, DisplayableAgent> inkAgentToObject= (agent)-> {
		Ink ink = (Ink) agent;
		return createObjectoToDisplayBasedOnInkType(ink);
	};*/
		
	/**
	 * java 8 functional interface example !
	 * take a displayableagent as parameter and output a displayObject
	 */
	Function<DisplayableAgent, DisplayableAgent> collectableAgentToObject= (agent)-> {
		Collectable collecatable = (Collectable) agent;
		CollectableDisplayObject object = new CollectableDisplayObject(collecatable);
		return object;
	};

	/**
	 * java 8 functionnal interface example
	 * @param map
	 * @param functionnal interface to transform objects
	 * @return a list from map
	 */
	private List<DisplayableAgent> agentMapToObjectList(Map<Long, DisplayableAgent> map, Function<DisplayableAgent, DisplayableAgent> function) {
		return map.values().parallelStream().map(agent -> function.apply(agent)).collect(Collectors.toList());
	}
	
	public void sendGameReadyMessage(){
		GameReadyMessage message = new GameReadyMessage();
		message.setGameReady(room.isGameReady());
		String messageString = stringfyMessage(message);
		pushToAllScreens(messageString);

	}
	
	public void sendGameRestartMessage(){
		GameRestartMessage message = new GameRestartMessage();
		message.setRestart(room.allPlayersRequestRestart());
		String messageString = stringfyMessage(message);
		pushToAllScreens(messageString);

	}
	
	/**
	 * send game end signal to all the players and screens
	 */
	public void sendGameEndMessage(){
		GameEndMessage message = new GameEndMessage();
		message.setGameEnd(room.isGameEnd());
		String messageString = stringfyMessage(message);
		pushToAllScreens(messageString);
		pushToAllPlayers(messageString);
	}
	

	public void sendAllPlayersReadyMessage(){
		AllPlayersReadyMessage message = new AllPlayersReadyMessage();
		message.setAllPlayersReady(room.allPlayersAreReady());
		String messageString = stringfyMessage(message);
		pushToAllScreens(messageString);
	}
	
	public void sendPlayerReadyCheckMessage(){
		PlayerReadyCheckMessage message = new PlayerReadyCheckMessage();
		String messageString = stringfyMessage(message);
		pushToAllPlayers(messageString);
	}
	
	public void sendPlayersInfosMessage(){
		PlayersInformationMessage message = new PlayersInformationMessage();
		message.adaptMessageContents(room.getPlayers());
		String messageString = stringfyMessage(message);
		pushToAllScreens(messageString);
	}
	
	private String stringfyMessage(ServerMessage message) {
		ObjectMapper mapper = new ObjectMapper();
		String messageString = null;
		try {
			messageString = mapper.writeValueAsString(message);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return messageString;
	}

	public void sendPlayerPointer(Player player) {
		if(player.getSocketSession() != null){
			PlayerPointerMessage message = new PlayerPointerMessage();
			message.setPointer(player.getPointerIcon());
			String messageString = stringfyMessage(message);
			pushToSession(player.getSocketSession(), messageString);
		}
	}

	public boolean isMasonStep() {
		return masonStep;
	}

	public void setMasonStep(boolean masonStep) {
		this.masonStep = masonStep;
	}
	
}
