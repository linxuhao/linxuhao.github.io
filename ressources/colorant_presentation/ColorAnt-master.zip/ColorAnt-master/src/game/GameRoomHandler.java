package game;

import java.util.HashMap;
import java.util.Map;

import game.model.GameRoom;

/**
 * The center of game room managing
 * @author Linxuhao
 *
 */
public class GameRoomHandler {
	
	public static Map<String, GameRoom> gamerooms = new HashMap<String, GameRoom>();
	
	/**
	 * Generate a unique game room id  
	 * @param username
	 * @param roomname
	 * @return
	 */
	public static String generateRoomId(String roomname){
		StringBuilder sb = new StringBuilder();
		sb.append(roomname);
		String roomId = sb.toString();
		//while the roomId exist, generate a new one
		int i = 1;
		while(gamerooms.get(roomId) != null){
			//append a number after the roomId
			roomId = sb.append(i).toString();
			i++;
		}
		return roomId;
	}
}
