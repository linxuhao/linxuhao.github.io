package game.constants;

/**
 * Type of messages between players and server, and between central screen and server
 * @author Linxuhao
 *
 */
public enum SocketMessageType {

	PlayerToServer,
	ServerToPlayer,
	CentralScreenToServer,
	ServerToCentralScreen;
	
}
