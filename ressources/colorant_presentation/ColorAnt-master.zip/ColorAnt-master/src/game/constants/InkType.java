package game.constants;

/**
 * Type of all inks
 * @author Linxuhao
 *
 */
public enum InkType {

	/**
	 * no ink
	 */
	None,
	/**
	 * indicates the direction
	 */
	Diriger,
	/**
	 * explode
	 */
	Exploser,
	/**
	 * get the closest collectible
	 */
	Collecter,
	/**
	 * drop the collectible
	 */
	Lacher,
	/**
	 * stucks the insect
	 */
	Immobiliser;
	
}
