package game.constants;

/**
 * the 4 positions for the scoring corner
 * @author Linxuhao
 *
 */
public enum ScoringCornerPosition {

	LEFT_TOP,
	RIGHT_TOP,
	LEFT_BOT,
	RIGHT_BOT;
	
}
