package game.constants;

/**
 * create a order in player pointer ids
 * @author Linxuhao
 *
 */
public enum PlayerPointerIds {

	CIRCLE("circle.png"),
	CROSS("cross.png"),
	TRIANGLE("triangle.png"),
	STAR("star.png");
	
	private String value;
	
	PlayerPointerIds(String value){
		this.value = value;
	}

	public String getValue() {
		return value;
	}
	
	@Override
	public String toString(){
		return value;
	}
}
