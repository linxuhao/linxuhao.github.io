package game.model;

import javax.websocket.Session;

import game.constants.InkType;
import mason.model.World;
import mason.model.PlayerPointer;

/**
 * A player is represented by a name, a session in socket and a roomId, also having a pointer and a color !
 * @author Linxuhao
 *
 */
public class Player extends SocketSessionHolder{

	private String roomId;
	private PlayerPointer positionPointer;
	private boolean ready;
	private String pointerIcon;
	private boolean requestRestart;
	
	/**
	 * create a new players with parameters below and position pointer as null
	 * <h1 style="color:red;"> a selected pointer as player pointer !</h1><br>
	 * @param roomId
	 * @param socketSession
	 * @param color
	 */
	public Player(String roomId, Session socketSession, String pointer) {
		super();
		this.roomId = roomId;
		this.socketSession = socketSession;
		this.positionPointer = null;
		this.setPointerIcon(pointer);
		this.ready = false;
		this.requestRestart = false;
	}

	public String getRoomId() {
		return roomId;
	}

	public void setRoomId(String roomId) {
		this.roomId = roomId;
	}

	public PlayerPointer getPositionPointer() {
		return this.positionPointer;
	}

	public void setPositionPointer(PlayerPointer positionPointer) {
		this.positionPointer = positionPointer;
	}
	
	/**
	 * ask player to move to a position and draw <br>
	 * if inkType == null then not drawing, only moving
	 * @param xMove
	 * @param yMove
	 * @param inkType
	 */
	public void moveToPositionAndDraw(World world, int xPos, int yPos, InkType inkType){
		PlayerPointer pointer = this.positionPointer;
		int newX = setWithinARange(xPos, 0, world.getWidth() - 1, 0, world.getWidth() - 1);
		int newY = setWithinARange( yPos, 0, world.getHeight() - 1, 0,  world.getHeight() - 1);
		pointer.setPositionAndDraw(world, inkType, newX, newY);
	}
	
	/**
	 * ask player to move and draw <br>
	 * if inkType == null then not drawing, only moving
	 * @param xMove
	 * @param yMove
	 * @param inkType
	 */
	public void moveAndDraw(World world, int xMove, int yMove, InkType inkType){
		PlayerPointer pointer = this.positionPointer;
		int newX = addWithinARange(pointer.getX(), xMove, 0, world.getWidth() - 1, 0, world.getWidth() - 1);
		int newY = addWithinARange(pointer.getY(), yMove, 0, world.getHeight() - 1, 0,  world.getHeight() - 1);
		pointer.setPositionAndDraw(world, inkType, newX, newY);
	}
	
	private int setWithinARange(int value, int minRange, int maxRange, int minNewValue, int maxNewValue) {
		int newValue = value;
		if(newValue > maxRange){
			newValue = maxNewValue;
		}
		if(newValue < minRange){
			newValue = minNewValue;
		}
		return newValue;
	}
	
	/**
	 * add 2 value, if the new value is not in the range, give it a new value
	 * @param value
	 * @param add
	 * @param minRange
	 * @param maxRange
	 * @param minNewValue
	 * @param maxNewValue
	 * @return
	 */
	private int addWithinARange(int value, int add, int minRange, int maxRange, int minNewValue, int maxNewValue) {
		int newValue = value + add;
		if(newValue > maxRange){
			newValue = maxNewValue;
		}
		if(newValue < minRange){
			newValue = minNewValue;
		}
		return newValue;
	}

	public boolean isReady() {
		return ready;
	}

	public void setReady(boolean ready) {
		this.ready = ready;
	}

	public boolean isRequestRestart() {
		return requestRestart;
	}

	public void setRequestRestart(boolean requestRestart) {
		this.requestRestart = requestRestart;
	}

	public String getPointerIcon() {
		return pointerIcon;
	}

	public void setPointerIcon(String pointerIcon) {
		this.pointerIcon = pointerIcon;
	}
}
