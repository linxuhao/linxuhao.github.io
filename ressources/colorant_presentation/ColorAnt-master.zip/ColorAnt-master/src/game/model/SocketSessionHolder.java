package game.model;

import javax.websocket.Session;

public abstract class SocketSessionHolder {
	
	protected Session socketSession;
	
	public Session getSocketSession() {
		return socketSession;
	}
	public void setSocketSession(Session socketSession) {
		this.socketSession = socketSession;
	}
}
