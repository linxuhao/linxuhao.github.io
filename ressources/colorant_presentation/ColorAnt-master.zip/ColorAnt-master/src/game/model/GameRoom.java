package game.model;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Stack;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.websocket.Session;

import game.GameRoomHandler;
import game.GameRunnerThread;
import helper.FileHelper;
import mason.model.World;
import mason.model.PlayerPointer;

/**
 * A game room !
 * @author Linxuhao
 *
 */
public class GameRoom {

	private int maxPlayerNumber;
	private String id;
	private CopyOnWriteArrayList<Player> players;
	private CopyOnWriteArrayList<Screen> screens;
	private World game;
	private File qRCode;
	/**
	 * if the game is started in free painting mode
	 */
	private boolean gameStarted;
	/**
	 * if the game is ready to be played
	 */
	private boolean gameReady;
	private GameRunnerThread gameRunnerThread;
	private boolean gameEnd;
	/**
	 * having id toward available pointers
	 */
	private Stack<String> availablePointerIcons;
	
	/**
	 * create a game room with custom max player number and custom size
	 * @param id
	 * @param qRCode
	 * @param maxPlayerNumber
	 */
	public GameRoom(String id, File qRCode, int width, int height) {
		super();
		this.id = id;
		this.setGame(new World(System.currentTimeMillis(), width, height,this));
		this.qRCode = qRCode;
		init();
		
	}

	/**
	 * init this class
	 */
	private void init() {
		this.players = new CopyOnWriteArrayList<Player>();
		this.gameStarted = false;
		this.setGameRunnerThread(new GameRunnerThread(this));
		this.screens = new CopyOnWriteArrayList<Screen>();
		this.maxPlayerNumber = 4;
		this.gameEnd = false;
		this.availablePointerIcons = FileHelper.loadPlayerPointers();
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public CopyOnWriteArrayList<Player> getPlayers() {
		return players;
	}
	public void setPlayers(CopyOnWriteArrayList<Player> players) {
		this.players = players;
	}
	public File getQRCode() {
		return this.qRCode;
	}

	public void setQRCode(File qRCode) {
		this.qRCode = qRCode;
	}

	public GameRunnerThread getGameRunnerThread() {
		return gameRunnerThread;
	}

	public void setGameRunnerThread(GameRunnerThread gameRunnerThread) {
		this.gameRunnerThread = gameRunnerThread;
	}

	public World getGame() {
		return game;
	}

	public void setGame(World game) {
		this.game = game;
	}

	public boolean isGameStarted() {
		return gameStarted;
	}

	public void setGameStarted(boolean gameStarted) {
		this.gameStarted = gameStarted;
	}
	
	/**
	 * 
	 * @return check if the game is ready or not, if is ready, return true
	 */
	public boolean isGameReady(){
		return this.gameReady;
	}

	/**
	 * update the game ready state, and re-initialize game zone to be rdy for game to begin 
	 * Tutorial Phase
	 */
	public void updateGameReady() {
		if(!this.gameReady){
			this.gameReady = this.maxPlayerNumber == this.players.size();
			//re initialize the game if game is ready in this call
			if(this.gameReady){
				this.startTutorial();
			}
		}
	}

	public void setGameReady(boolean gameReady) {
		this.gameReady = gameReady;
	}

	public CopyOnWriteArrayList<Screen> getScreens() {
		return screens;
	}

	public void setScreens(CopyOnWriteArrayList<Screen> screen) {
		this.screens = screen;
	}

	public int getMaxPlayerNumber() {
		return maxPlayerNumber;
	}

	public void setMaxPlayerNumber(int maxPlayerNumber) {
		this.maxPlayerNumber = maxPlayerNumber;
	}

	public boolean isGameEnd() {
		return gameEnd;
	}

	public void setGameEnd(boolean gameEnd) {
		this.gameEnd = gameEnd;
	}
	
	/**
	 * Send player removed notification to display
	 * @param session
	 * @return the removed player
	 */
	public Player removePlayerBySession(Session session){
		Player playerToRemove = players.stream().filter(player -> player.getSocketSession() != null)
				.filter(player -> player.getSocketSession().getId().equals(session.getId())).findFirst().get();
		PlayerPointer pointerToRemove = playerToRemove.getPositionPointer();
		String pointerIcon = playerToRemove.getPointerIcon();
		this.availablePointerIcons.push(pointerIcon);
		this.getGame().getYard().remove(pointerToRemove);
		//delete cross references
		pointerToRemove.setPlayer(null);
		if(playerToRemove.getPositionPointer().getScoringCorner() != null){
			playerToRemove.getPositionPointer().getScoringCorner().setPlayer(null);
			playerToRemove.getPositionPointer().setScoringCorner(null);
		}
		playerToRemove.setPositionPointer(null);
		players.remove(playerToRemove);
		return playerToRemove;
	}
	

	public void removeScreenBySession(Session session) {
		Screen screenToRemove = screens.stream().filter(screnn -> screnn.getSocketSession().getId().equals(session.getId())).findFirst().get();
		screens.remove(screenToRemove);
		
	}

	public Player findPlayerBySession(Session session){
		return players.stream().filter(player -> player.getSocketSession() != null)
				.filter(player -> player.getSocketSession().getId().equals(session.getId())).findFirst().orElse(null);
	}
	

	public Screen findScreenBySession(Session session) {
		return screens.stream().filter(screen -> screen.getSocketSession() != null)
				.filter(screen -> screen.getSocketSession().getId().equals(session.getId())).findFirst().orElse(null);
	}

	
	/**
	 * start the game in free painting mode, waiting all players to be ready
	 * TODO : remove inks when starting game
	 */
	public void startGame(){
		if(!this.gameStarted){
			this.gameStarted = true;
			this.game.startEmpty();
			//name this thread, so i can find it in debug mode xD
			Thread thread = new Thread(this.gameRunnerThread, this.id + " - GameRunnerThread");
			thread.start();
		}
	}
	
	/**
	 * start the Tutorial
	 */
	public void startTutorial(){
		this.game.start();
		//send tutorial signal to display
		this.getGameRunnerThread().sendGameReadyMessage();
		//send player ready check information to players
		this.getGameRunnerThread().sendPlayerReadyCheckMessage();
	}
	
	/**
	 * close a game
	 */
	public void closeGame(){
		if(this.gameStarted){
			this.gameRunnerThread.stop();
			this.gameStarted = false;
			this.game.finish();
			//close socket session with all players
			closeAllSocketForPlayers(players);
			closeAllSocketForScreens(screens);
			GameRoomHandler.gamerooms.remove(this.id);
			//delete the cross reference
			this.game.setRoom(null);
			this.game = null;
			System.out.println("game room: " + id +" closing");
		}
	}

	/**
	 * copy on write list does not work with their mother class SocketSessionHolder
	 * @param players
	 */
	private void closeAllSocketForPlayers(CopyOnWriteArrayList<Player> players) {
		players.stream().filter(socket -> socket.getSocketSession() != null)
		.forEach(socket -> {
			try {
				socket.getSocketSession().close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
	}
	
	private void closeAllSocketForScreens(CopyOnWriteArrayList<Screen> screens) {
		screens.stream().filter(socket -> socket.getSocketSession() != null)
		.forEach(socket -> {
			try {
				socket.getSocketSession().close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
	}
	
	/**
	 * add a new player in this game room and set up his pointer ( adding it to the map )
	 * @param roomid
	 * @param username
	 * @param session
	 * @return the added player or null if failed add a player
	 */
	public Player addPlayerAndSetUpPointer(World world, Session session){
		if(!availablePointerIcons.isEmpty()){
			Player player = new Player(id, session, availablePointerIcons.pop());
			int centerX = world.getWidth() / 2;
			int centerY = world.getHeight() / 2;
			PlayerPointer pointer = new PlayerPointer(world, player, centerX ,centerY);
			player.setPositionPointer(pointer);
			players.add(player);
			//add pointer on map
			getGame().getYard().setObjectLocation(pointer, pointer.getX(), pointer.getY());
			return player;
		}
		return null;
		
	}

	public boolean allPlayersAreReady(){
		return players.stream().filter(player -> player.isReady()).count() == this.maxPlayerNumber;
	}
	
	public boolean allPlayersRequestRestart(){
		return players.stream().filter(player -> player.isRequestRestart()).count() == this.maxPlayerNumber;
	}

	/**
	 * fill fake players with null session and force start the game
	 * @param player 
	 */
	public void forceStartTheGame() {
		//add fake players to full
		int playerNumberNeeded = maxPlayerNumber - players.size();
		for(int i = 0; i< playerNumberNeeded; i++){
			Player fakePlayer = new Player(id, null, availablePointerIcons.pop());
			players.add(fakePlayer);
		}
		//set all players ready
		players.stream().forEach(player -> player.setReady(true));
		this.updateGameReady();
		this.game.setStartingTime(System.currentTimeMillis());
	}

	public void restartTheGame() {
		this.players.stream().forEach(player -> player.setRequestRestart(false));
		this.game.observer.clear();
		this.game.start();
		this.game.setStartingTime(System.currentTimeMillis());
		setGameEnd(false);
	}
	
	public List<String> findAvailablesPointerIcons(){
		return availablePointerIcons.subList(0, availablePointerIcons.size());
	}

}
