package game.model.display;

import mason.model.ComplexDisplayableAgent;

public class MonsterDisplayObject extends ComplexDisplayObject{

	public MonsterDisplayObject(ComplexDisplayableAgent agent) {
		super(agent);
	}

}
