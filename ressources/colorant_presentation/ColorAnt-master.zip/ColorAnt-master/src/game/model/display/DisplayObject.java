package game.model.display;

import mason.model.DisplayableAgent;

/**
 * A simple Object we want to display, have it's type and position, this goes directly to the front
 * Is the concret class of displayableAgent
 * @author Linxuhao
 *
 */
public abstract class DisplayObject extends DisplayableAgent {
	
	/**
	 * create a display object at position (x,y) with DisplayType = type
	 * @param x
	 * @param y
	 */
	public DisplayObject(DisplayableAgent agent) {
		super();
		this.displayId = agent.getDisplayId();
		this.x = agent.getX();
		this.y = agent.getY();
	}
}
