package game.model.display;

import mason.model.ComplexDisplayableAgent;

/**
 * the message to display insects
 * @author Linxuhao
 *
 */
public class InsectDisplayObject extends ComplexDisplayObject{

	public InsectDisplayObject(ComplexDisplayableAgent agent) {
		super(agent);
	}

}
