package game.model.display;

import game.constants.InkType;
import mason.model.DisplayableAgent;

public class PlayerPointerDisplayObject extends DisplayObject{

	private InkType currentInkType;
	
	public PlayerPointerDisplayObject(DisplayableAgent agent, InkType type) {
		super(agent);
		this.currentInkType = type;
	}

	public InkType getCurrentInkType() {
		return currentInkType;
	}

	public void setCurrentInkType(InkType currentInkType) {
		this.currentInkType = currentInkType;
	}

}
