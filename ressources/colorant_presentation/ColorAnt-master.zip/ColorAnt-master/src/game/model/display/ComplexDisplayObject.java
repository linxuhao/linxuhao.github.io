package game.model.display;

import mason.model.ComplexDisplayableAgent;

/**
 * Object we want to display, have it's type and position, this goes directly to the front
 * Is the concret class of displayableAgent
 * @author Linxuhao
 *
 */
public abstract class ComplexDisplayObject extends ComplexDisplayableAgent {
	
	/**
	 * create a display object at position (x,y) with DisplayType = type
	 * @param x
	 * @param y
	 */
	public ComplexDisplayObject(ComplexDisplayableAgent agent) {
		super();
		this.displayId = agent.getDisplayId();
		this.x = agent.getX();
		this.y = agent.getY();
		this.goalX = agent.getGoalX();
		this.goalY = agent.getGoalY();
		this.speed = agent.getSpeed();
		this.state = agent.getState();
	}
}
