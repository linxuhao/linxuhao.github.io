package game.model.display;

import mason.model.ComplexDisplayableAgent;

/**
 * to display collectables
 * @author Linxuhao
 *
 */
public class CollectableDisplayObject extends ComplexDisplayObject{

	public CollectableDisplayObject(ComplexDisplayableAgent agent) {
		super(agent);
	}

}
