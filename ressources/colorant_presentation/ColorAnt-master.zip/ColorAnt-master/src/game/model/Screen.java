package game.model;


/**
 * object representing the central screen
 * @author Linxuhao
 *
 */
public class Screen extends SocketSessionHolder{

	private String roomId;

	
	public String getRoomId() {
		return roomId;
	}
	public void setRoomId(String roomId) {
		this.roomId = roomId;
	}

	
	
}
