# ColorAnt

ColorAnt !!!!!!!

## Getting Started

This is only source code and the libs, so you need to create a dynamic web project on eclipse (select tomcat 9.0 as server, and download one)s

### Prerequisites

Tomcat 9 as the server

```
Download a CORE binary distribution from here https://tomcat.apache.org/download-90.cgi.
Then unzip somewhere on your local machine, then tell eclipse where you unziped it
```
Java jre1.8.0_121
```
Download and install and add path variable to operating system to make java 8 work, check tutorial on internet xD
```


## Deployment

In eclipse, when you finished setting the project up, you can right click on project to add it on a existing local server, then you can test it by running the local server
The url to this web app is 
```
http://localhost:8080/ColorAnt/
```
If you didnt change the port number in web.xml
Otherwise use your custom port number to replace 8080.


